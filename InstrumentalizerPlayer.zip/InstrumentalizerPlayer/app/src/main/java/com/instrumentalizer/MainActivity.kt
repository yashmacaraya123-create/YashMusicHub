package com.instrumentalizer

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.ActivityInfo
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.OpenableColumns
import androidx.activity.ComponentActivity
import androidx.activity.compose.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.*
import androidx.compose.ui.graphics.*
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackParameters
import androidx.media3.common.Player
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.audio.AudioSink
import androidx.media3.exoplayer.audio.DefaultAudioSink
import androidx.media3.ui.PlayerView
import kotlinx.coroutines.*
import kotlin.math.pow
import kotlin.math.roundToInt

private val Bg = Color(0xFF0E0B1F)
private val PanelC = Color(0xFF181440)
private val Cyan = Color(0xFF5EEAD4)
private val Violet = Color(0xFFC084FC)
private val Pink = Color(0xFFF472B6)
private val Brand = Brush.linearGradient(listOf(Cyan, Violet, Pink))
private val DarkC = darkColorScheme(primary = Cyan, onPrimary = Bg, secondary = Violet, tertiary = Pink,
    background = Bg, surface = Bg, surfaceVariant = PanelC, onBackground = Color(0xFFEDEBFF),
    onSurface = Color(0xFFEDEBFF), onSurfaceVariant = Color(0xFFA9A5D0), outline = Color(0xFF3A3470),
    secondaryContainer = Color(0xFF3A2C75), onSecondaryContainer = Color(0xFFEDEBFF))
private val LightC = lightColorScheme(primary = Color(0xFF0F766E), secondary = Color(0xFF7C3AED), tertiary = Color(0xFFDB2777),
    background = Color(0xFFF6F4FF), surface = Color(0xFFF6F4FF), surfaceVariant = Color(0xFFFFFFFF),
    onSurfaceVariant = Color(0xFF5B5780), outline = Color(0xFFD5D0F0))

fun fmt(ms: Long): String { val t = (ms / 1000).toInt(); return if (t >= 3600) "${t / 3600}:%02d:%02d".format(t / 60 % 60, t % 60) else "${t / 60}:%02d".format(t % 60) }
fun Context.findActivity(): Activity? { var c: Context = this; while (c is ContextWrapper) { if (c is Activity) return c; c = c.baseContext }; return null }
fun keyText(k: Int) = if (k > 0) "+$k" else "$k"

class MainActivity : ComponentActivity() {
    val incoming = mutableStateOf<Uri?>(null)
    override fun onCreate(s: Bundle?) { super.onCreate(s); incoming.value = uriFrom(intent); setContent { App(incoming) } }
    override fun onNewIntent(intent: Intent) { super.onNewIntent(intent); incoming.value = uriFrom(intent) }
    @Suppress("DEPRECATION")
    private fun uriFrom(i: Intent?): Uri? = when (i?.action) {
        Intent.ACTION_VIEW -> i?.data
        Intent.ACTION_SEND -> if (Build.VERSION.SDK_INT >= 33) i?.getParcelableExtra(Intent.EXTRA_STREAM, Uri::class.java) else i?.getParcelableExtra<Uri>(Intent.EXTRA_STREAM)
        else -> null }
}

@Composable fun BrandButton(text: String, enabled: Boolean = true, onClick: () -> Unit) {
    Box(Modifier.clip(RoundedCornerShape(50)).background(if (enabled) Brand else Brush.linearGradient(listOf(Color(0xFF555070), Color(0xFF555070))))
        .clickable(enabled = enabled, onClick = onClick).padding(horizontal = 30.dp, vertical = 16.dp), Alignment.Center) {
        Text(text, color = Bg, fontWeight = FontWeight.Bold, fontSize = 16.sp) } }
@Composable fun Card(content: @Composable ColumnScope.() -> Unit) {
    val sh = RoundedCornerShape(26.dp)
    Column(Modifier.fillMaxWidth().clip(sh).background(MaterialTheme.colorScheme.surfaceVariant)
        .border(1.dp, MaterialTheme.colorScheme.outline, sh).padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp), content = content) }
@Composable fun Label(t: String) = Text(t.uppercase(), color = MaterialTheme.colorScheme.primary, fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp)
@Composable fun Hint(t: String) = Text(t, color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 13.sp)
@Composable fun Chips(opts: List<Pair<String, String>>, sel: String, onSel: (String) -> Unit) {
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { opts.forEach { (k, l) -> FilterChip(sel == k, { onSel(k) }, { Text(l) }) } } }
@Composable fun RoundBtn(t: String, onClick: () -> Unit) {
    Box(Modifier.size(56.dp).clip(CircleShape).border(1.5.dp, MaterialTheme.colorScheme.primary, CircleShape).clickable(onClick = onClick), Alignment.Center) {
        Text(t, color = MaterialTheme.colorScheme.primary, fontSize = 26.sp, fontWeight = FontWeight.Bold) } }
@Composable fun Logo() {
    Box(Modifier.size(104.dp).clip(RoundedCornerShape(30.dp)).background(Color(0xFF101535)).border(1.5.dp, Brand, RoundedCornerShape(30.dp)), Alignment.Center) {
        Image(painterResource(R.drawable.ic_launcher_foreground), null, Modifier.size(104.dp).scale(1.45f)) } }
@Composable fun Equalizer(active: Boolean, modifier: Modifier = Modifier) {
    val t by rememberInfiniteTransition(label = "eq").animateFloat(0f, 1f, infiniteRepeatable(tween(1800, easing = LinearEasing)), label = "t")
    Canvas(modifier) {
        val n = 28; val gap = size.width / n; val w = gap * 0.55f
        for (i in 0 until n) {
            val a = if (active) 0.22f + 0.78f * kotlin.math.abs(kotlin.math.sin(t * 2f * Math.PI.toFloat() * (1 + i % 3) + i * 0.55f)) else 0.16f
            val h = size.height * a
            drawRoundRect(Brand, Offset(i * gap + (gap - w) / 2, (size.height - h) / 2), Size(w, h), CornerRadius(w / 2)) } } }
@Composable fun PlayPause(playing: Boolean, size: Int, onClick: () -> Unit) {
    Box(Modifier.size(size.dp).clip(CircleShape).background(Brand).clickable(onClick = onClick), Alignment.Center) {
        Canvas(Modifier.size((size * 0.37f).dp)) {
            if (playing) { val w = this.size.width * 0.32f
                drawRoundRect(Bg, Offset(this.size.width * 0.05f, 0f), Size(w, this.size.height), CornerRadius(4f))
                drawRoundRect(Bg, Offset(this.size.width * 0.63f, 0f), Size(w, this.size.height), CornerRadius(4f))
            } else { val p = Path().apply { moveTo(this@Canvas.size.width * 0.12f, 0f); lineTo(this@Canvas.size.width, this@Canvas.size.height / 2)
                lineTo(this@Canvas.size.width * 0.12f, this@Canvas.size.height); close() }; drawPath(p, Bg) } } } }
@Composable fun Page(content: @Composable ColumnScope.() -> Unit) {
    Column(Modifier.fillMaxSize().statusBarsPadding().verticalScroll(rememberScrollState()).padding(22.dp), verticalArrangement = Arrangement.spacedBy(14.dp), content = content) }

@Composable fun App(incoming: MutableState<Uri?>) {
    val ctx = LocalContext.current
    val prefs = remember { ctx.getSharedPreferences("p", 0) }
    var theme by remember { mutableStateOf(prefs.getString("theme", "system")!!) }
    var skip by remember { mutableIntStateOf(prefs.getInt("skip", 10)) }
    var keepOn by remember { mutableStateOf(prefs.getBoolean("keep", true)) }
    var keepKT by remember { mutableStateOf(prefs.getBoolean("remember", false)) }
    var engine by remember { mutableStateOf(if (prefs.getBoolean("hq", true)) "best" else "light") }
    var page by remember { mutableStateOf("home") }
    var uri by remember { mutableStateOf<Uri?>(null) }
    var name by remember { mutableStateOf("") }
    var isVideo by remember { mutableStateOf(false) }
    var playerKey by remember { mutableIntStateOf(0) }
    var msg by remember { mutableStateOf<String?>(null) }
    var askExport by remember { mutableStateOf(false) }
    var expSemi by remember { mutableIntStateOf(0) }
    var expTempo by remember { mutableFloatStateOf(1f) }
    var exportP by remember { mutableStateOf<Float?>(null) }
    var exportMsg by remember { mutableStateOf<String?>(null) }
    var exportCancel by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    fun open(u: Uri) {
        uri = u; msg = null; exportMsg = null; name = "Selected file"
        ctx.contentResolver.query(u, null, null, null, null)?.use { c ->
            val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME); if (c.moveToFirst() && i >= 0) name = c.getString(i) }
        var v = ctx.contentResolver.getType(u)?.startsWith("video") == true
        if (!v) try { val r = MediaMetadataRetriever(); r.setDataSource(ctx, u)
            v = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_HAS_VIDEO) == "yes"; r.release() } catch (_: Throwable) {}
        isVideo = v; playerKey++; page = "player" }
    val pick = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u -> if (u != null) open(u) }
    LaunchedEffect(incoming.value) { incoming.value?.let { open(it); incoming.value = null } }

    fun runExport(dest: Uri, kind: String) {
        exportCancel = false; exportP = 0f; exportMsg = null
        val s = expSemi; val sp = expTempo.toDouble(); val src = uri!!
        scope.launch(Dispatchers.Default) {
            try { Exporter.export(ctx, src, dest, kind, sp, s, prefs.getBoolean("hq", true), { exportCancel }) { exportP = it }; exportMsg = "Saved." }
            catch (e: CancellationException) { exportMsg = "Export cancelled." }
            catch (e: Throwable) { exportMsg = "Could not export: ${e.message}" }
            exportP = null } }
    val createMp4 = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("video/mp4")) { u -> if (u != null) runExport(u, "mp4") }
    val createM4a = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("audio/mp4")) { u -> if (u != null) runExport(u, "m4a") }
    val createWav = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("audio/wav")) { u -> if (u != null) runExport(u, "wav") }
    fun put(k: String, v: String) = prefs.edit().putString(k, v).apply()

    val dark = when (theme) { "dark" -> true; "light" -> false; else -> isSystemInDarkTheme() }
    MaterialTheme(colorScheme = if (dark) DarkC else LightC) {
        Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
            when (page) {
                "settings" -> Page {
                    Text("Settings", fontSize = 28.sp, fontWeight = FontWeight.ExtraBold)
                    Hint("Changes save instantly. The audio engine applies to the next file you open.")
                    Card { Label("Appearance"); Chips(listOf("system" to "System", "light" to "Light", "dark" to "Dark"), theme) { theme = it; put("theme", it) } }
                    Card { Label("Skip button")
                        Chips(listOf(5, 10, 15, 30).map { "$it" to "${it}s" }, "$skip") { skip = it.toInt(); prefs.edit().putInt("skip", skip).apply() } }
                    Card { Label("Playback")
                        Row(verticalAlignment = Alignment.CenterVertically) { Text("Keep screen on during video", Modifier.weight(1f))
                            Switch(keepOn, { keepOn = it; prefs.edit().putBoolean("keep", it).apply() }) }
                        Row(verticalAlignment = Alignment.CenterVertically) { Text("Remember key and tempo for the next file", Modifier.weight(1f))
                            Switch(keepKT, { keepKT = it; prefs.edit().putBoolean("remember", it).apply() }) } }
                    Card { Label("Audio engine")
                        Chips(listOf("best" to "Best quality", "light" to "Battery saver"), engine) { engine = it; prefs.edit().putBoolean("hq", it == "best").apply() }
                        Hint("Best quality sounds the most natural. Battery saver uses less processor power.") }
                    BrandButton("Back") { page = "home" }
                }
                "player" -> key(playerKey) {
                    PlayerScreen(uri!!, name, isVideo, prefs, skip, keepOn, keepKT, exportP, exportMsg, { exportCancel = true },
                        { s, t -> expSemi = s; expTempo = t; askExport = true }, { page = "home" }) }
                else -> Column(Modifier.fillMaxSize().statusBarsPadding().verticalScroll(rememberScrollState()).padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(14.dp)) {
                    Row(Modifier.fillMaxWidth(), Arrangement.End) { TextButton({ page = "settings" }) { Text("Settings") } }
                    Spacer(Modifier.height(16.dp))
                    Logo()
                    Text("Instrumentalizer Player", style = TextStyle(brush = Brand, fontSize = 28.sp, fontWeight = FontWeight.ExtraBold))
                    Hint("Any key. Any tempo.")
                    Spacer(Modifier.height(10.dp))
                    Card {
                        Equalizer(false, Modifier.fillMaxWidth().height(70.dp))
                        BrandButton("Open a video or song") { pick.launch(arrayOf("video/*", "audio/*")) }
                        Hint("Tip: you can also use Open with from your Files app, or from Instrumentalizer.") }
                    msg?.let { Text(it, color = MaterialTheme.colorScheme.error) }
                }
            }
            if (askExport) AlertDialog(onDismissRequest = { askExport = false }, confirmButton = {}, title = { Text("Export") },
                text = { Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Hint("With key ${keyText(expSemi)} and tempo ${(expTempo * 100).roundToInt()}%")
                    val base = name.substringBeforeLast('.') + "-key${keyText(expSemi)}-${(expTempo * 100).roundToInt()}pct"
                    if (isVideo) OutlinedButton({ askExport = false; createMp4.launch("$base.mp4") }, Modifier.fillMaxWidth()) { Text("Video (MP4)") }
                    OutlinedButton({ askExport = false; createM4a.launch("$base.m4a") }, Modifier.fillMaxWidth()) { Text("Audio (M4A)") }
                    OutlinedButton({ askExport = false; createWav.launch("$base.wav") }, Modifier.fillMaxWidth()) { Text("Audio (WAV, lossless)") } } },
                dismissButton = { TextButton({ askExport = false }) { Text("Cancel") } })
        }
    }
}

@Composable fun W(t: String, onClick: () -> Unit) =
    TextButton(onClick, colors = ButtonDefaults.textButtonColors(contentColor = Color.White)) { Text(t, fontSize = 15.sp) }

@Composable fun PlayerScreen(uri: Uri, name: String, isVideo: Boolean, prefs: SharedPreferences, skip: Int, keepOn: Boolean, keepKT: Boolean,
                             exportP: Float?, exportMsg: String?, onCancelExport: () -> Unit, onExport: (Int, Float) -> Unit, onBack: () -> Unit) {
    val ctx = LocalContext.current
    var semi by remember { mutableIntStateOf(if (keepKT) prefs.getInt("lastSemi", 0) else 0) }
    var tempo by remember { mutableFloatStateOf(if (keepKT) prefs.getFloat("lastTempo", 1f) else 1f) }
    var vol by remember { mutableFloatStateOf(1f) }
    var muted by remember { mutableStateOf(false) }
    var playing by remember { mutableStateOf(true) }
    var pos by remember { mutableLongStateOf(0) }
    var dur by remember { mutableLongStateOf(1) }
    var drag by remember { mutableStateOf<Float?>(null) }
    var full by remember { mutableStateOf(false) }
    var showCtl by remember { mutableStateOf(true) }
    var touch by remember { mutableIntStateOf(0) }
    val chain = remember { RbChain { prefs.getBoolean("hq", true) } }
    val exo = remember {
        val rf = object : DefaultRenderersFactory(ctx) {   // our Rubber Band audio chain replaces ExoPlayer's built-in speed/pitch
            override fun buildAudioSink(context: Context, enableFloatOutput: Boolean, enableAudioTrackPlaybackParams: Boolean): AudioSink =
                DefaultAudioSink.Builder(context).setAudioProcessorChain(chain).setEnableFloatOutput(false)
                    .setEnableAudioTrackPlaybackParams(false).build() }
        ExoPlayer.Builder(ctx, rf).build().apply { setMediaItem(MediaItem.fromUri(uri)); prepare(); playWhenReady = true } }

    DisposableEffect(Unit) {
        val act = ctx.findActivity() as? ComponentActivity
        val obs = LifecycleEventObserver { _, e -> if (e == Lifecycle.Event.ON_STOP) exo.pause() }
        act?.lifecycle?.addObserver(obs)
        onDispose { act?.lifecycle?.removeObserver(obs); exo.release() } }
    DisposableEffect(full) {
        val act = ctx.findActivity()
        if (act != null) { val c = WindowCompat.getInsetsController(act.window, act.window.decorView)
            if (full) { act.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
                c.hide(WindowInsetsCompat.Type.systemBars()); c.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            } else { act.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED; c.show(WindowInsetsCompat.Type.systemBars()) } }
        onDispose { act?.let { it.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
            WindowCompat.getInsetsController(it.window, it.window.decorView).show(WindowInsetsCompat.Type.systemBars()) } } }
    BackHandler(full) { full = false }
    LaunchedEffect(semi, tempo) {
        exo.playbackParameters = PlaybackParameters(tempo, 2f.pow(semi / 12f))
        if (keepKT) prefs.edit().putInt("lastSemi", semi).putFloat("lastTempo", tempo).apply() }
    LaunchedEffect(vol, muted) { exo.volume = if (muted) 0f else vol }
    LaunchedEffect(Unit) { while (true) { pos = exo.currentPosition; val d = exo.duration; dur = if (d > 0) d else 1L; playing = exo.isPlaying; delay(250) } }
    LaunchedEffect(showCtl, touch) { if (full && showCtl) { delay(3500); showCtl = false } }

    fun toggle() { if (exo.playWhenReady && exo.playbackState != Player.STATE_ENDED) exo.pause()
        else { if (exo.playbackState == Player.STATE_ENDED) exo.seekTo(0); exo.play() } }
    fun jump(s: Int) { exo.seekTo((exo.currentPosition + s * 1000L).coerceIn(0L, dur)) }
    fun tempoStep(d: Float) { tempo = (((tempo + d) * 20).roundToInt() / 20f).coerceIn(0.5f, 1.5f) }
    val sc = SliderDefaults.colors(thumbColor = Cyan, activeTrackColor = Cyan)

    if (full) {
        Box(Modifier.fillMaxSize().background(Color.Black)) {
            AndroidView({ PlayerView(it).apply { player = exo; useController = false; keepScreenOn = keepOn } }, Modifier.fillMaxSize())
            Box(Modifier.fillMaxSize().clickable(remember { MutableInteractionSource() }, null) { showCtl = !showCtl; touch++ })
            if (showCtl) Column(Modifier.fillMaxSize().background(Color(0x66000000)).padding(horizontal = 24.dp, vertical = 12.dp), Arrangement.SpaceBetween) {
                Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween, Alignment.CenterVertically) {
                    Text(name, color = Color.White, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
                    W("Exit fullscreen") { full = false } }
                Row(Modifier.fillMaxWidth(), Arrangement.Center, Alignment.CenterVertically) {
                    W("◀ ${skip}s") { jump(-skip); touch++ }; Spacer(Modifier.width(20.dp))
                    PlayPause(playing, 72) { toggle(); touch++ }; Spacer(Modifier.width(20.dp))
                    W("${skip}s ▶") { jump(skip); touch++ } }
                Column {
                    Slider(drag ?: pos.toFloat(), { drag = it; touch++ }, valueRange = 0f..dur.toFloat(), colors = sc,
                        onValueChangeFinished = { drag?.let { exo.seekTo(it.toLong()) }; drag = null })
                    Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween, Alignment.CenterVertically) {
                        Text("${fmt(pos)} / ${fmt(dur)}", color = Color.White, fontSize = 13.sp)
                        W("Key −") { if (semi > -12) semi--; touch++ }; Text(keyText(semi), color = Color.White, fontWeight = FontWeight.Bold); W("Key +") { if (semi < 12) semi++; touch++ }
                        W("Tempo −") { tempoStep(-0.05f); touch++ }; Text("${(tempo * 100).roundToInt()}%", color = Color.White, fontWeight = FontWeight.Bold); W("Tempo +") { tempoStep(0.05f); touch++ }
                        W(if (muted) "Unmute" else "Mute") { muted = !muted; touch++ } } } }
        }
    } else Page {
        Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween, Alignment.CenterVertically) {
            Text(name, fontSize = 20.sp, fontWeight = FontWeight.ExtraBold, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
            TextButton(onBack) { Text("Back") } }
        Card {
            if (isVideo) AndroidView({ PlayerView(it).apply { player = exo; useController = false; keepScreenOn = keepOn } },
                Modifier.fillMaxWidth().aspectRatio(16 / 9f).clip(RoundedCornerShape(16.dp)))
            else Equalizer(playing, Modifier.fillMaxWidth().height(120.dp))
            Slider(drag ?: pos.toFloat(), { drag = it }, valueRange = 0f..dur.toFloat(), colors = sc,
                onValueChangeFinished = { drag?.let { exo.seekTo(it.toLong()) }; drag = null })
            Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween) { Hint(fmt(pos)); Hint(fmt(dur)) }
            Row(Modifier.fillMaxWidth(), Arrangement.SpaceEvenly, Alignment.CenterVertically) {
                OutlinedButton({ jump(-skip) }) { Text("◀ ${skip}s") }
                PlayPause(playing, 76) { toggle() }
                OutlinedButton({ jump(skip) }) { Text("${skip}s ▶") } }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
                FilterChip(muted, { muted = !muted }, { Text("Mute") })
                Slider(vol, { vol = it; muted = false }, Modifier.weight(1f), valueRange = 0f..1f, colors = sc)
                if (isVideo) OutlinedButton({ full = true; showCtl = true }) { Text("Fullscreen") } } }
        Card {
            Label("Key")
            Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween, Alignment.CenterVertically) {
                RoundBtn("−") { if (semi > -12) semi-- }
                Text(keyText(semi), fontSize = 44.sp, fontWeight = FontWeight.ExtraBold)
                RoundBtn("+") { if (semi < 12) semi++ } }
            Hint("Semitones. Tempo stays the same.") }
        Card {
            Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween, Alignment.CenterVertically) {
                Label("Tempo"); Text("${(tempo * 100).roundToInt()}%", fontSize = 24.sp, fontWeight = FontWeight.ExtraBold) }
            Slider(tempo, { tempo = (it * 20).roundToInt() / 20f }, valueRange = 0.5f..1.5f, colors = sc)
            Hint("Pitch stays the same.") }
        Row(Modifier.fillMaxWidth(), Arrangement.spacedBy(10.dp)) {
            OutlinedButton({ semi = 0; tempo = 1f }, Modifier.weight(1f)) { Text("Reset") }
            OutlinedButton({ onExport(semi, tempo) }, Modifier.weight(1f), enabled = exportP == null) { Text("Export") } }
        exportP?.let { p -> Card { Label("Exporting"); LinearProgressIndicator({ p }, Modifier.fillMaxWidth()); Hint("${(p * 100).roundToInt()}%. Keep the app open.")
            OutlinedButton(onCancelExport) { Text("Cancel") } } }
        exportMsg?.let { Text(it, color = if (it.startsWith("Could")) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary) }
    }
}
