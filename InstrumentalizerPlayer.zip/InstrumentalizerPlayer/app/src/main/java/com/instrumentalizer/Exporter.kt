package com.instrumentalizer

import android.content.Context
import android.media.*
import android.net.Uri
import android.os.PowerManager
import java.io.*
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.min
import kotlin.math.pow

/** Renders the whole file with the chosen key and tempo. Video is copied untouched (only its timestamps are scaled). */
object Exporter {
    private interface Sink { fun write(s: ShortArray, n: Int); fun finish() }

    private class WavSink(val f: File, val sr: Int) : Sink {
        val raf = RandomAccessFile(f, "rw"); var bytes = 0L
        init { raf.setLength(0); raf.write(ByteArray(44)) }
        override fun write(s: ShortArray, n: Int) {
            val b = ByteBuffer.allocate(n * 2).order(ByteOrder.LITTLE_ENDIAN); b.asShortBuffer().put(s, 0, n); raf.write(b.array()); bytes += n * 2 }
        override fun finish() {
            val h = ByteBuffer.allocate(44).order(ByteOrder.LITTLE_ENDIAN)
            h.put("RIFF".toByteArray()).putInt((36 + bytes).toInt()).put("WAVEfmt ".toByteArray()).putInt(16)
                .putShort(1).putShort(2).putInt(sr).putInt(sr * 4).putShort(4).putShort(16).put("data".toByteArray()).putInt(bytes.toInt())
            raf.seek(0); raf.write(h.array()); raf.close() }
    }

    private class AacSink(f: File, val sr: Int) : Sink {
        val enc: MediaCodec = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_AUDIO_AAC)
        val out = DataOutputStream(BufferedOutputStream(FileOutputStream(f)))
        var outFmt: MediaFormat? = null; var frames = 0L; val info = MediaCodec.BufferInfo()
        init {
            val af = MediaFormat.createAudioFormat(MediaFormat.MIMETYPE_AUDIO_AAC, sr, 2).apply {
                setInteger(MediaFormat.KEY_AAC_PROFILE, MediaCodecInfo.CodecProfileLevel.AACObjectLC)
                setInteger(MediaFormat.KEY_BIT_RATE, 192000); setInteger(MediaFormat.KEY_MAX_INPUT_SIZE, 65536) }
            enc.configure(af, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE); enc.start()
        }
        private fun drain(wait: Long): Boolean {
            while (true) {
                val oi = enc.dequeueOutputBuffer(info, wait)
                if (oi >= 0) {
                    val ob = enc.getOutputBuffer(oi)!!
                    if (info.size > 0 && info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG == 0) {
                        val b = ByteArray(info.size); ob.position(info.offset); ob.limit(info.offset + info.size); ob.get(b)
                        out.writeInt(info.size); out.writeLong(info.presentationTimeUs); out.writeInt(info.flags); out.write(b) }
                    enc.releaseOutputBuffer(oi, false)
                    if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) return true
                } else if (oi == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) outFmt = enc.outputFormat
                else return false
            }
        }
        override fun write(s: ShortArray, n: Int) {
            var pos = 0
            while (pos < n) {
                drain(0)
                val ii = enc.dequeueInputBuffer(5000)
                if (ii >= 0) {
                    val b = enc.getInputBuffer(ii)!!; b.clear()
                    var k = min(b.remaining() / 2, n - pos); k -= k % 2
                    b.order(ByteOrder.nativeOrder()).asShortBuffer().put(s, pos, k)
                    enc.queueInputBuffer(ii, 0, k * 2, frames * 1_000_000L / sr, 0); frames += k / 2; pos += k }
            }
        }
        override fun finish() {
            var ii: Int; do { ii = enc.dequeueInputBuffer(10000) } while (ii < 0)
            enc.queueInputBuffer(ii, 0, 0, frames * 1_000_000L / sr, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
            while (!drain(10000)) { }
            enc.stop(); enc.release(); out.close()
        }
    }

    private fun toStereo(s: ShortArray, off: Int, ch: Int, l: FloatArray, r: FloatArray, i: Int) {
        when (ch) {
            1 -> { val a = s[off] / 32768f; l[i] = a; r[i] = a }
            2 -> { l[i] = s[off] / 32768f; r[i] = s[off + 1] / 32768f }
            else -> { val c = s[off + 2] / 32768f * 0.707f
                l[i] = (s[off] / 32768f + c + (if (ch > 4) s[off + 4] / 32768f * 0.5f else 0f)) * 0.6f
                r[i] = (s[off + 1] / 32768f + c + (if (ch > 5) s[off + 5] / 32768f * 0.5f else 0f)) * 0.6f }
        }
    }

    /** kind: "mp4" (video + audio), "m4a" (AAC audio), "wav" */
    fun export(ctx: Context, src: Uri, dest: Uri, kind: String, speed: Double, semis: Int, hq: Boolean,
               cancel: () -> Boolean, onP: (Float) -> Unit) {
        val wl = ctx.getSystemService(PowerManager::class.java).newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "player:export")
        wl.acquire(2 * 3600 * 1000L)
        val rec = File(ctx.cacheDir, "aac.rec"); val wavF = File(ctx.cacheDir, "out.wav"); val outF = File(ctx.cacheDir, "export.$kind")
        val ex = MediaExtractor().apply { setDataSource(ctx, src, null) }
        try {
            val ai = (0 until ex.trackCount).firstOrNull { ex.getTrackFormat(it).getString(MediaFormat.KEY_MIME)!!.startsWith("audio/") }
                ?: throw IllegalStateException("This file has no audio.")
            ex.selectTrack(ai)
            val fmt = ex.getTrackFormat(ai)
            val codec = MediaCodec.createDecoderByType(fmt.getString(MediaFormat.KEY_MIME)!!)
            codec.configure(fmt, null, null, 0); codec.start()
            var ch = fmt.getInteger(MediaFormat.KEY_CHANNEL_COUNT); val sr = fmt.getInteger(MediaFormat.KEY_SAMPLE_RATE)
            val durUs = if (fmt.containsKey(MediaFormat.KEY_DURATION)) fmt.getLong(MediaFormat.KEY_DURATION) else 0L
            val rb = RbStream(sr, hq); rb.start(1.0 / speed, 2.0.pow(semis / 12.0))
            val sink: Sink = if (kind == "wav") WavSink(wavF, sr) else AacSink(rec, sr)
            val l = FloatArray(2048); val r = FloatArray(2048); val outS = ShortArray(4096); var tmp = ShortArray(65536)
            fun pump() {
                var av = rb.ready()
                while (av > 0) {
                    val g = rb.read(l, r, min(av, 2048)); if (g <= 0) break
                    for (i in 0 until g) { outS[2 * i] = (l[i].coerceIn(-1f, 1f) * 32767f).toInt().toShort(); outS[2 * i + 1] = (r[i].coerceIn(-1f, 1f) * 32767f).toInt().toShort() }
                    sink.write(outS, g * 2); av -= g }
            }
            val info = MediaCodec.BufferInfo(); var inDone = false; var outDone = false
            while (!outDone) {
                if (cancel()) throw java.util.concurrent.CancellationException()
                if (!inDone) {
                    val i = codec.dequeueInputBuffer(10000)
                    if (i >= 0) {
                        val sz = ex.readSampleData(codec.getInputBuffer(i)!!, 0)
                        if (sz < 0) { codec.queueInputBuffer(i, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM); inDone = true }
                        else { codec.queueInputBuffer(i, 0, sz, ex.sampleTime, 0); ex.advance() } }
                }
                val o = codec.dequeueOutputBuffer(info, 10000)
                if (o >= 0) {
                    val sb = codec.getOutputBuffer(o)!!.order(ByteOrder.nativeOrder()).asShortBuffer()
                    val k = info.size / 2
                    if (k > tmp.size) tmp = ShortArray(k)
                    sb.get(tmp, 0, k)
                    val frames = k / ch; var done = 0
                    while (done < frames) {
                        val n = min(2048, frames - done)
                        for (i in 0 until n) toStereo(tmp, (done + i) * ch, ch, l, r, i)
                        rb.feed(l, r, n); done += n; pump() }
                    codec.releaseOutputBuffer(o, false)
                    if (durUs > 0) onP(min(1f, info.presentationTimeUs.toFloat() / durUs))
                    if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) outDone = true
                } else if (o == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) ch = codec.outputFormat.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
            }
            codec.stop(); codec.release()
            rb.finish(); pump(); sink.finish(); rb.release()

            if (kind == "wav") { ctx.contentResolver.openOutputStream(dest)!!.use { o -> wavF.inputStream().use { i -> i.copyTo(o) } }; return }
            val mux = MediaMuxer(outF.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
            var vEx: MediaExtractor? = null
            try {
                var vIdx = -1
                if (kind == "mp4") {
                    val ve = MediaExtractor().apply { setDataSource(ctx, src, null) }; vEx = ve
                    val vi = (0 until ve.trackCount).firstOrNull { ve.getTrackFormat(it).getString(MediaFormat.KEY_MIME)!!.startsWith("video/") }
                        ?: throw IllegalStateException("This file has no video.")
                    ve.selectTrack(vi); val vf = ve.getTrackFormat(vi)
                    if (vf.containsKey(MediaFormat.KEY_ROTATION)) mux.setOrientationHint(vf.getInteger(MediaFormat.KEY_ROTATION))
                    vIdx = try { mux.addTrack(vf) } catch (e: Throwable) { throw IllegalStateException("This video format can't be put in an MP4 file. Export the audio instead.") }
                }
                val aIdx = mux.addTrack((sink as AacSink).outFmt ?: throw IllegalStateException("Audio encoding failed."))
                mux.start()
                vEx?.let { ve ->
                    val vb = ByteBuffer.allocate(8 * 1024 * 1024); val bi = MediaCodec.BufferInfo()
                    while (true) {
                        val sz = ve.readSampleData(vb, 0); if (sz < 0) break
                        bi.set(0, sz, (ve.sampleTime / speed).toLong(), ve.sampleFlags and MediaExtractor.SAMPLE_FLAG_SYNC)
                        mux.writeSampleData(vIdx, vb, bi); ve.advance() } }
                DataInputStream(BufferedInputStream(FileInputStream(rec))).use { inp ->
                    val bi = MediaCodec.BufferInfo()
                    try { while (true) {
                        val size = inp.readInt(); val pts = inp.readLong(); val flags = inp.readInt()
                        val b = ByteArray(size); inp.readFully(b); bi.set(0, size, pts, flags)
                        mux.writeSampleData(aIdx, ByteBuffer.wrap(b), bi) } } catch (_: EOFException) { } }
                mux.stop()
            } finally { mux.release(); vEx?.release() }
            ctx.contentResolver.openOutputStream(dest)!!.use { o -> outF.inputStream().use { i -> i.copyTo(o) } }
        } finally { ex.release(); rec.delete(); wavF.delete(); outF.delete(); if (wl.isHeld) wl.release() }
    }
}
