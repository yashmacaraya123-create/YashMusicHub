package com.instrumentalizer

import androidx.media3.common.C
import androidx.media3.common.PlaybackParameters
import androidx.media3.common.audio.AudioProcessor
import androidx.media3.common.audio.BaseAudioProcessor
import androidx.media3.exoplayer.audio.DefaultAudioSink
import java.nio.ByteBuffer
import java.nio.ByteOrder

/** Plugs Rubber Band into ExoPlayer's audio path: ExoPlayer keeps picture, seeking and sync; we change key/tempo. */
class RbAudioProcessor(private val hq: () -> Boolean) : BaseAudioProcessor() {
    @Volatile var speed = 1.0
    @Volatile var pitch = 1.0
    private var rb: RbStream? = null
    private var ch = 2
    private var lastSpeed = -1.0; private var lastPitch = -1.0
    private val l = FloatArray(2048); private val r = FloatArray(2048); private val frame = FloatArray(8)

    override fun onConfigure(f: AudioProcessor.AudioFormat): AudioProcessor.AudioFormat {
        if (f.encoding != C.ENCODING_PCM_16BIT || f.channelCount > 8) throw AudioProcessor.UnhandledAudioFormatException(f)
        ch = f.channelCount
        rb?.release(); rb = RbStream(f.sampleRate, hq())
        return AudioProcessor.AudioFormat(f.sampleRate, 2, C.ENCODING_PCM_16BIT)
    }
    override fun onFlush() { rb?.start(1.0 / speed, pitch); lastSpeed = speed; lastPitch = pitch }
    override fun onReset() { rb?.release(); rb = null }

    override fun queueInput(inputBuffer: ByteBuffer) {
        val s = rb ?: return
        if (speed != lastSpeed || pitch != lastPitch) { s.setParams(1.0 / speed, pitch); lastSpeed = speed; lastPitch = pitch }
        val bpf = 2 * ch
        while (inputBuffer.remaining() >= bpf) {
            val n = minOf(2048, inputBuffer.remaining() / bpf)
            for (i in 0 until n) {
                var a: Float; var b: Float
                when (ch) {
                    1 -> { a = inputBuffer.short / 32768f; b = a }
                    2 -> { a = inputBuffer.short / 32768f; b = inputBuffer.short / 32768f }
                    else -> {   // simple downmix to stereo
                        for (k in 0 until ch) frame[k] = inputBuffer.short / 32768f
                        a = (frame[0] + 0.707f * frame[2] + (if (ch > 4) 0.5f * frame[4] else 0f)) * 0.6f
                        b = (frame[1] + 0.707f * frame[2] + (if (ch > 5) 0.5f * frame[5] else 0f)) * 0.6f
                    }
                }
                l[i] = a; r[i] = b
            }
            s.feed(l, r, n)
        }
        drain(s)
    }
    override fun onQueueEndOfStream() { rb?.let { it.finish(); drain(it) } }

    private fun drain(s: RbStream) {
        val total = s.ready()
        if (total <= 0) return
        val out = replaceOutputBuffer(total * 4).order(ByteOrder.nativeOrder())
        var left = total
        while (left > 0) {
            val g = s.read(l, r, minOf(left, 2048)); if (g <= 0) break
            for (i in 0 until g) { out.putShort((l[i].coerceIn(-1f, 1f) * 32767f).toInt().toShort()); out.putShort((r[i].coerceIn(-1f, 1f) * 32767f).toInt().toShort()) }
            left -= g
        }
        out.flip()
    }
}

class RbChain(hq: () -> Boolean) : DefaultAudioSink.AudioProcessorChain {
    private val proc = RbAudioProcessor(hq)
    private var spd = 1f
    override fun getAudioProcessors(): Array<AudioProcessor> = arrayOf(proc)
    override fun applyPlaybackParameters(p: PlaybackParameters): PlaybackParameters {
        proc.speed = p.speed.toDouble(); proc.pitch = p.pitch.toDouble(); spd = p.speed; return p }
    override fun applySkipSilenceEnabled(skipSilenceEnabled: Boolean) = false
    override fun getMediaDuration(playoutDuration: Long) = (playoutDuration * spd).toLong()
    override fun getSkippedOutputFrameCount() = 0L
}
