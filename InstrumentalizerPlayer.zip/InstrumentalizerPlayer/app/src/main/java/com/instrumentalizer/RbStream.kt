package com.instrumentalizer

/** Rubber Band wrapper: stereo float in, stereo float out. Key (pitch) and tempo (time ratio) are independent. */
class RbStream(sr: Int, hq: Boolean) {
    companion object { init { System.loadLibrary("rb_jni") } }
    private external fun nCreate(sr: Int, hq: Boolean): Long
    private external fun nSet(h: Long, ratio: Double, pitch: Double)
    private external fun nProcess(h: Long, l: FloatArray, r: FloatArray, n: Int)
    private external fun nFinal(h: Long)
    private external fun nAvailable(h: Long): Int
    private external fun nRetrieve(h: Long, l: FloatArray, r: FloatArray, n: Int): Int
    private external fun nReset(h: Long)
    private external fun nPad(h: Long): Int
    private external fun nDelay(h: Long): Int
    private external fun nDestroy(h: Long)

    private val h = nCreate(sr, hq)
    private val zeros = FloatArray(2048)
    private val sl = FloatArray(2048); private val sr2 = FloatArray(2048)
    private var skip = 0

    /** (Re)start a stream. Feeds the recommended start padding and drops the start delay so output lines up with input. */
    fun start(ratio: Double, pitch: Double) {
        nReset(h); nSet(h, ratio, pitch); skip = nDelay(h)
        var pad = nPad(h)
        while (pad > 0) { val n = minOf(pad, 2048); nProcess(h, zeros, zeros, n); pad -= n }
    }
    fun setParams(ratio: Double, pitch: Double) = nSet(h, ratio, pitch)
    fun feed(l: FloatArray, r: FloatArray, n: Int) = nProcess(h, l, r, n)
    fun finish() = nFinal(h)
    /** frames ready to read */
    fun ready(): Int {
        while (skip > 0) {
            val a = nAvailable(h); if (a <= 0) return 0
            skip -= nRetrieve(h, sl, sr2, minOf(skip, a, 2048))
        }
        return maxOf(0, nAvailable(h))
    }
    fun read(l: FloatArray, r: FloatArray, n: Int): Int = nRetrieve(h, l, r, n)
    fun release() = nDestroy(h)
}
