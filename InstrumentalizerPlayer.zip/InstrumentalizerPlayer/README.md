# Instrumentalizer Player
Video/audio player with independent key (±12 semitones) and tempo (50-150%) via Rubber Band (GPL v2+),
integrated into ExoPlayer's audio path so picture/seek/sync stay native. Export with key+tempo to MP4/M4A/WAV.
Build: clone Rubber Band into app/src/main/cpp/rubberband (see apk.yml). arm64 phones.
