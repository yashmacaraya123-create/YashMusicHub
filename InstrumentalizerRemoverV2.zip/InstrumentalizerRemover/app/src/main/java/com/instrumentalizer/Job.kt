package com.instrumentalizer

import kotlinx.coroutines.flow.MutableStateFlow
import java.io.File

data class JobState(val progress: Float? = null, val eta: Int? = null, val wav: File? = null, val error: String? = null)

object Job {
    val state = MutableStateFlow(JobState())
    @Volatile var cancel = false
}
