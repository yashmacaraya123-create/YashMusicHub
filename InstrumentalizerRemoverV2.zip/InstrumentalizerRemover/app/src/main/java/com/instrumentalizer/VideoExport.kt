package com.instrumentalizer

import android.content.Context
import android.media.*
import android.net.Uri
import java.io.File
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.max
import kotlin.math.min

/** Original picture (copied untouched, no re-encode) + instrumental audio (AAC) -> MP4. */
object VideoExport {
    private const val SR = 44100

    fun export(ctx: Context, src: Uri, wav: File, fromSec: Double, toSec: Double, dest: Uri) {
        val ex = MediaExtractor().apply { setDataSource(ctx, src, null) }
        val outFile = File(ctx.cacheDir, "video_out.mp4"); outFile.delete()
        try {
            val vi = (0 until ex.trackCount).firstOrNull { ex.getTrackFormat(it).getString(MediaFormat.KEY_MIME)!!.startsWith("video/") }
                ?: throw IllegalStateException("No video found in this file.")
            val vFormat = ex.getTrackFormat(vi)
            ex.selectTrack(vi)
            ex.seekTo((fromSec * 1e6).toLong(), MediaExtractor.SEEK_TO_PREVIOUS_SYNC)
            val vStart = max(0L, ex.sampleTime)                       // picture starts at the nearest earlier keyframe
            val gap = max(0, ((fromSec * 1e6 - vStart) / 1e6 * SR).toInt())   // so pad the audio with silence to stay in sync
            val b = ByteBuffer.wrap(wav.readBytes()).order(ByteOrder.LITTLE_ENDIAN); b.position(44)
            val sh = ShortArray(b.remaining() / 2); b.asShortBuffer().get(sh)
            val pcm = ShortArray(gap * 2 + sh.size).also { System.arraycopy(sh, 0, it, gap * 2, sh.size) }

            // 1) encode the audio to AAC
            val enc = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_AUDIO_AAC)
            val af = MediaFormat.createAudioFormat(MediaFormat.MIMETYPE_AUDIO_AAC, SR, 2).apply {
                setInteger(MediaFormat.KEY_AAC_PROFILE, MediaCodecInfo.CodecProfileLevel.AACObjectLC)
                setInteger(MediaFormat.KEY_BIT_RATE, 192000); setInteger(MediaFormat.KEY_MAX_INPUT_SIZE, 65536) }
            enc.configure(af, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE); enc.start()
            val chunks = ArrayList<Pair<ByteArray, MediaCodec.BufferInfo>>()
            var outFmt: MediaFormat? = null
            var pos = 0; var inDone = false; var done = false
            val info = MediaCodec.BufferInfo()
            while (!done) {
                if (!inDone) {
                    val ii = enc.dequeueInputBuffer(10000)
                    if (ii >= 0) {
                        val buf = enc.getInputBuffer(ii)!!; buf.clear()
                        val n = min(min(buf.remaining() / 2, pcm.size - pos), 8192)
                        val pts = (pos / 2).toLong() * 1_000_000L / SR
                        if (n <= 0) { enc.queueInputBuffer(ii, 0, 0, pts, MediaCodec.BUFFER_FLAG_END_OF_STREAM); inDone = true }
                        else { buf.order(ByteOrder.nativeOrder()).asShortBuffer().put(pcm, pos, n)
                            enc.queueInputBuffer(ii, 0, n * 2, pts, 0); pos += n }
                    }
                }
                val oi = enc.dequeueOutputBuffer(info, 10000)
                if (oi >= 0) {
                    val ob = enc.getOutputBuffer(oi)!!
                    if (info.size > 0 && info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG == 0) {
                        val bytes = ByteArray(info.size); ob.position(info.offset); ob.limit(info.offset + info.size); ob.get(bytes)
                        chunks.add(bytes to MediaCodec.BufferInfo().apply { set(0, info.size, info.presentationTimeUs, info.flags) })
                    }
                    enc.releaseOutputBuffer(oi, false)
                    if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) done = true
                } else if (oi == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) outFmt = enc.outputFormat
            }
            enc.stop(); enc.release()

            // 2) mux: untouched video samples + AAC audio
            val mux = MediaMuxer(outFile.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
            try {
                if (vFormat.containsKey(MediaFormat.KEY_ROTATION)) mux.setOrientationHint(vFormat.getInteger(MediaFormat.KEY_ROTATION))
                val vIdx = try { mux.addTrack(vFormat) } catch (e: Throwable) {
                    throw IllegalStateException("This video format can't be put in an MP4 file. Save the audio instead.") }
                val aIdx = mux.addTrack(outFmt ?: throw IllegalStateException("Audio encoding failed."))
                mux.start()
                val vb = ByteBuffer.allocate(8 * 1024 * 1024); val bi = MediaCodec.BufferInfo()
                val toUs = (toSec * 1e6).toLong()
                while (true) {
                    val sz = ex.readSampleData(vb, 0); if (sz < 0) break
                    val t = ex.sampleTime; if (t > toUs) break
                    bi.set(0, sz, max(0L, t - vStart), ex.sampleFlags and MediaExtractor.SAMPLE_FLAG_SYNC)
                    mux.writeSampleData(vIdx, vb, bi); ex.advance()
                }
                for ((bytes, i) in chunks) mux.writeSampleData(aIdx, ByteBuffer.wrap(bytes), i)
                mux.stop()
            } finally { mux.release() }
            ctx.contentResolver.openOutputStream(dest)!!.use { o -> outFile.inputStream().use { it.copyTo(o) } }
        } finally { ex.release(); outFile.delete() }
    }
}
