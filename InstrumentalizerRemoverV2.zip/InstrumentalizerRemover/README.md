# Instrumentalizer (vocal removal app)
Models: Studio = htdemucs (fp32), Balanced = htdemucs int8, Fast = Balanced with minimal overlap.
Video input: save as MP4 (original picture copied untouched + instrumental AAC audio).
Signed with the fixed app/debug.keystore so updates install over older builds and keep the models.
