package com.instrumentalizer

import android.content.Context
import android.net.Uri
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

/** The voice-removal model lives in app storage. Downloaded once, then everything is offline. */
object ModelStore {
    const val URL = "https://huggingface.co/ferrite-stems/htdemucs-onnx-dml/resolve/main/htdemucs-dml.onnx"
    fun file(c: Context) = File(c.filesDir, "model.onnx")

    suspend fun download(c: Context, onP: (Float) -> Unit) = withContext(Dispatchers.IO) {
        val tmp = File(c.filesDir, "model.part")
        val con = URL(URL).openConnection() as HttpURLConnection
        con.connectTimeout = 15000; con.readTimeout = 30000; con.connect()
        val total = con.contentLengthLong
        con.inputStream.use { i -> tmp.outputStream().use { o ->
            val b = ByteArray(65536); var n = 0L
            while (true) { val r = i.read(b); if (r < 0) break; o.write(b, 0, r); n += r
                if (total > 0) onP(n.toFloat() / total) } } }
        if (tmp.length() < 50_000_000) { tmp.delete(); throw IllegalStateException("incomplete file") }
        file(c).delete(); tmp.renameTo(file(c))
    }

    fun import(c: Context, uri: Uri) {
        val tmp = File(c.filesDir, "model.part")
        c.contentResolver.openInputStream(uri)!!.use { i -> tmp.outputStream().use { i.copyTo(it) } }
        file(c).delete(); tmp.renameTo(file(c))
    }
}
