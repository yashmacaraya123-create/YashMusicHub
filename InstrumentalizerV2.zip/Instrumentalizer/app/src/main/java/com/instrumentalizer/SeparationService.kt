package com.instrumentalizer

import android.app.*
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.drawable.Icon
import android.os.IBinder
import android.os.PowerManager

/** Foreground service + wake lock: vocal removal keeps going with the screen off or the app in the background. */
class SeparationService : Service() {
    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        if (i?.action == "cancel") { Job.cancel = true; return START_NOT_STICKY }
        val uri = i?.data ?: return START_NOT_STICKY
        val overlap = i.getFloatExtra("overlap", 0.25f)
        val threads = i.getIntExtra("threads", 3)
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("sep", "Vocal removal", NotificationManager.IMPORTANCE_LOW))
        val cancelPi = PendingIntent.getService(this, 1,
            Intent(this, SeparationService::class.java).setAction("cancel"), PendingIntent.FLAG_IMMUTABLE)
        fun notif(p: Int) = Notification.Builder(this, "sep")
            .setSmallIcon(android.R.drawable.stat_sys_download).setContentTitle("Removing vocals")
            .setContentText("$p%").setProgress(100, p, false).setOngoing(true)
            .addAction(Notification.Action.Builder(Icon.createWithResource(this, android.R.drawable.ic_delete), "Cancel", cancelPi).build())
            .build()
        startForeground(1, notif(0), ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        Job.cancel = false; Job.state.value = JobState(0f)
        Thread {
            // low priority: worker threads inherit it, so the rest of the phone stays smooth
            android.os.Process.setThreadPriority(android.os.Process.THREAD_PRIORITY_BACKGROUND)
            val wl = getSystemService(PowerManager::class.java)
                .newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "instrumentalizer:sep")
            wl.acquire(2 * 60 * 60 * 1000L)
            try {
                val f = Separator.run(this@SeparationService, uri, overlap, threads, { Job.cancel }) { p ->
                    Job.state.value = JobState(p); nm.notify(1, notif((p * 100).toInt())) }
                Job.state.value = JobState(wav = f)
            } catch (e: java.util.concurrent.CancellationException) { Job.state.value = JobState()
            } catch (e: Throwable) { Job.state.value = JobState(error = e.message ?: "Could not process this file")
            } finally { if (wl.isHeld) wl.release() }
            stopForeground(STOP_FOREGROUND_REMOVE); stopSelf()
        }.start()
        return START_NOT_STICKY
    }
}
