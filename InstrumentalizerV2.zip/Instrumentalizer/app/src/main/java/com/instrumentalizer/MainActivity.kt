@file:OptIn(androidx.media3.common.util.UnstableApi::class)
package com.instrumentalizer

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.*
import androidx.compose.ui.graphics.*
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import kotlinx.coroutines.*
import java.io.File

// ---- Brand: deep-indigo "studio" look with a cyan -> violet -> pink accent ----
private val Bg = Color(0xFF0E0B1F)
private val PanelC = Color(0xFF181440)
private val Cyan = Color(0xFF5EEAD4)
private val Violet = Color(0xFFC084FC)
private val Pink = Color(0xFFF472B6)
private val Brand = Brush.linearGradient(listOf(Cyan, Violet, Pink))
private val DarkC = darkColorScheme(primary = Cyan, onPrimary = Bg, secondary = Violet, tertiary = Pink,
    background = Bg, surface = Bg, surfaceVariant = PanelC, onBackground = Color(0xFFEDEBFF),
    onSurface = Color(0xFFEDEBFF), onSurfaceVariant = Color(0xFFA9A5D0), outline = Color(0xFF3A3470),
    secondaryContainer = Color(0xFF3A2C75), onSecondaryContainer = Color(0xFFEDEBFF))
private val LightC = lightColorScheme(primary = Color(0xFF0F766E), secondary = Color(0xFF7C3AED), tertiary = Color(0xFFDB2777),
    background = Color(0xFFF6F4FF), surface = Color(0xFFF6F4FF), surfaceVariant = Color(0xFFFFFFFF),
    onSurfaceVariant = Color(0xFF5B5780), outline = Color(0xFFD5D0F0))

class MainActivity : ComponentActivity() {
    override fun onCreate(s: Bundle?) { super.onCreate(s); setContent { App() } }
}

@Composable fun BrandButton(text: String, onClick: () -> Unit) {
    Box(Modifier.clip(RoundedCornerShape(50)).background(Brand).clickable(onClick = onClick)
        .padding(horizontal = 30.dp, vertical = 16.dp), Alignment.Center) {
        Text(text, color = Bg, fontWeight = FontWeight.Bold, fontSize = 16.sp) } }

@Composable fun Card(content: @Composable ColumnScope.() -> Unit) {
    val sh = RoundedCornerShape(26.dp)
    Column(Modifier.fillMaxWidth().clip(sh).background(MaterialTheme.colorScheme.surfaceVariant)
        .border(1.dp, MaterialTheme.colorScheme.outline, sh).padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp), content = content) }

@Composable fun Label(t: String) = Text(t.uppercase(), color = MaterialTheme.colorScheme.primary,
    fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp)

@Composable fun Hint(t: String) = Text(t, color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 13.sp)

@Composable fun Chips(opts: List<Pair<String, String>>, sel: String, onSel: (String) -> Unit) {
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        opts.forEach { (k, l) -> FilterChip(sel == k, { onSel(k) }, { Text(l) }) } } }

@Composable fun RoundBtn(t: String, onClick: () -> Unit) {
    Box(Modifier.size(56.dp).clip(CircleShape).border(1.5.dp, MaterialTheme.colorScheme.primary, CircleShape)
        .clickable(onClick = onClick), Alignment.Center) {
        Text(t, color = MaterialTheme.colorScheme.primary, fontSize = 26.sp, fontWeight = FontWeight.Bold) } }

@Composable fun Logo() {
    Box(Modifier.size(104.dp).clip(RoundedCornerShape(30.dp)).background(Color(0xFF14102B))
        .border(1.5.dp, Brand, RoundedCornerShape(30.dp)), Alignment.Center) {
        Image(painterResource(R.drawable.ic_launcher_foreground), null, Modifier.size(104.dp).scale(1.45f)) } }

/** Animated equalizer: dances while playing/processing, flat when idle. */
@Composable fun Equalizer(active: Boolean, modifier: Modifier = Modifier) {
    val t by rememberInfiniteTransition(label = "eq").animateFloat(0f, 1f,
        infiniteRepeatable(tween(1800, easing = LinearEasing)), label = "t")
    Canvas(modifier) {
        val n = 28; val gap = size.width / n; val w = gap * 0.55f
        for (i in 0 until n) {
            val a = if (active) 0.22f + 0.78f * kotlin.math.abs(kotlin.math.sin(t * 2f * Math.PI.toFloat() * (1 + i % 3) + i * 0.55f)) else 0.16f
            val h = size.height * a
            drawRoundRect(Brand, Offset(i * gap + (gap - w) / 2, (size.height - h) / 2), Size(w, h), CornerRadius(w / 2)) } } }

@Composable fun App() {
    val ctx = LocalContext.current
    val prefs = remember { ctx.getSharedPreferences("s", 0) }
    var theme by remember { mutableStateOf(prefs.getString("theme", "system")!!) }
    var quality by remember { mutableStateOf(prefs.getString("q2", "balanced")!!) }
    var cpu by remember { mutableStateOf(prefs.getString("cpu", "smooth")!!) }
    var keepOn by remember { mutableStateOf(prefs.getBoolean("keep", true)) }
    var page by remember { mutableStateOf("home") }
    var src by remember { mutableStateOf<Uri?>(null) }
    var wav by remember { mutableStateOf<File?>(null) }
    var video by remember { mutableStateOf(false) }
    var msg by remember { mutableStateOf<String?>(null) }
    var dl by remember { mutableStateOf<Float?>(null) }
    var modelReady by remember { mutableStateOf(ModelStore.file(ctx).exists()) }
    val js by Job.state.collectAsState()
    val scope = rememberCoroutineScope()
    LaunchedEffect(js.wav) { js.wav?.let { wav = it; page = "player" } }
    fun put(k: String, v: String) = prefs.edit().putString(k, v).apply()
    fun download() {
        dl = 0f; msg = null
        scope.launch {
            try { ModelStore.download(ctx) { dl = it }; modelReady = true }
            catch (e: Throwable) { msg = "Download failed: ${e.message}" }
            dl = null } }

    val pick = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            src = uri; video = ctx.contentResolver.getType(uri)?.startsWith("video") == true; msg = null
            val cores = Runtime.getRuntime().availableProcessors()
            ctx.startForegroundService(Intent(ctx, SeparationService::class.java).setData(uri)
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                .putExtra("overlap", when (quality) { "fast" -> 0.1f; "studio" -> 0.5f; else -> 0.25f })
                .putExtra("threads", if (cpu == "fast") (cores - 1).coerceAtLeast(2) else (cores / 2 - 1).coerceAtLeast(2)))
        }
    }
    val importer = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u ->
        if (u != null) scope.launch(Dispatchers.IO) {
            try { ModelStore.import(ctx, u); modelReady = true } catch (e: Throwable) { msg = "Import failed: ${e.message}" } } }
    val askNotif = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {}
    LaunchedEffect(Unit) { if (android.os.Build.VERSION.SDK_INT >= 33) askNotif.launch(android.Manifest.permission.POST_NOTIFICATIONS) }
    val save = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("audio/wav")) { u ->
        if (u != null) ctx.contentResolver.openOutputStream(u)?.use { o -> wav?.inputStream()?.use { it.copyTo(o) } } }

    val dark = when (theme) { "dark" -> true; "light" -> false; else -> isSystemInDarkTheme() }
    MaterialTheme(colorScheme = if (dark) DarkC else LightC) {
        Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
            when (page) {
                "settings" -> Column(Modifier.fillMaxSize().statusBarsPadding().verticalScroll(rememberScrollState()).padding(24.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)) {
                    Text("Settings", fontSize = 28.sp, fontWeight = FontWeight.ExtraBold)
                    Card { Label("Appearance"); Chips(listOf("system" to "System", "light" to "Light", "dark" to "Dark"), theme) { theme = it; put("theme", it) } }
                    Card {
                        Label("Vocal removal")
                        Chips(listOf("fast" to "Fast", "balanced" to "Balanced", "studio" to "Studio"), quality) { quality = it; put("q2", it) }
                        Hint("Studio overlaps the most for the cleanest result but takes about twice as long as Fast.")
                        Label("Phone load")
                        Chips(listOf("smooth" to "Smooth", "fast" to "Fast"), cpu) { cpu = it; put("cpu", it) }
                        Hint("Smooth keeps your phone responsive while it works. Fast finishes sooner but may lag.") }
                    Card { Label("Playback")
                        Row(verticalAlignment = Alignment.CenterVertically) { Text("Keep screen on during video", Modifier.weight(1f))
                            Switch(keepOn, { keepOn = it; prefs.edit().putBoolean("keep", it).apply() }) } }
                    Card { Label("Background")
                        Hint("If processing stops when you leave the app, allow background running and set this app's battery to Unrestricted.")
                        OutlinedButton({ ctx.startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)) }) { Text("Allow background running") } }
                    Card { Label("Storage")
                        Hint(if (modelReady) "Voice model installed (about 170 MB)." else "Voice model not installed.")
                        if (modelReady) OutlinedButton({ ModelStore.file(ctx).delete(); modelReady = false }) { Text("Delete model") }
                        else OutlinedButton({ page = "home"; download() }) { Text("Download model") }
                        OutlinedButton({ ctx.cacheDir.listFiles()?.forEach { it.delete() }; wav = null }) { Text("Clear temporary files") } }
                    BrandButton("Back") { page = "home" }
                }
                "player" -> PlayerScreen(src!!, wav!!, video, keepOn, { page = "home" }, { save.launch("instrumental.wav") })
                else -> Column(Modifier.fillMaxSize().statusBarsPadding().verticalScroll(rememberScrollState()).padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(14.dp)) {
                    Row(Modifier.fillMaxWidth(), Arrangement.End) { TextButton({ page = "settings" }) { Text("Settings") } }
                    Spacer(Modifier.height(16.dp))
                    Logo()
                    Text("Instrumentalizer", style = TextStyle(brush = Brand, fontSize = 32.sp, fontWeight = FontWeight.ExtraBold))
                    Hint("Vocals out. Music in. Key and tempo, your way.")
                    Spacer(Modifier.height(10.dp))
                    val p = js.progress
                    Card {
                        when {
                            dl != null -> { Label("Setting up"); Text("Downloading voice model… ${((dl ?: 0f) * 100).toInt()}%")
                                LinearProgressIndicator({ dl ?: 0f }, Modifier.fillMaxWidth()); Hint("One time only. Keep the app open.") }
                            !modelReady -> { Label("One-time setup")
                                Text("Download the voice-removal model (about 170 MB). After this, everything works offline.")
                                BrandButton("Download model") { download() }
                                TextButton({ importer.launch(arrayOf("*/*")) }) { Text("I already have the file") } }
                            p != null -> { Equalizer(true, Modifier.fillMaxWidth().height(70.dp))
                                Text("Removing vocals… ${(p * 100).toInt()}%", fontWeight = FontWeight.SemiBold)
                                LinearProgressIndicator({ p }, Modifier.fillMaxWidth())
                                Hint("Keeps running in the background.")
                                OutlinedButton({ Job.cancel = true }) { Text("Cancel") } }
                            else -> { Equalizer(false, Modifier.fillMaxWidth().height(70.dp))
                                BrandButton("Choose a song or video") { pick.launch(arrayOf("audio/*", "video/*")) }
                                if (wav != null) TextButton({ page = "player" }) { Text("Back to last track") } }
                        }
                    }
                    (msg ?: js.error)?.let { Text(it, color = MaterialTheme.colorScheme.error) }
                }
            }
        }
    }
}

@Composable fun PlayerScreen(src: Uri, wav: File, video: Boolean, keepOn: Boolean, onBack: () -> Unit, onSave: () -> Unit) {
    val ctx = LocalContext.current
    var semi by remember { mutableIntStateOf(0) }
    var tempo by remember { mutableFloatStateOf(1f) }
    var playing by remember { mutableStateOf(true) }
    var pos by remember { mutableLongStateOf(0) }
    val engine = remember { RbEngine(wav).also { it.play() } }   // Rubber Band is the audio master clock
    val vp = remember { if (!video) null else ExoPlayer.Builder(ctx).build().apply {   // picture only, original audio disabled
        trackSelectionParameters = trackSelectionParameters.buildUpon().setTrackTypeDisabled(C.TRACK_TYPE_AUDIO, true).build()
        setMediaItem(MediaItem.fromUri(src)); prepare(); playWhenReady = true } }
    DisposableEffect(Unit) { onDispose { engine.release(); vp?.release() } }
    LaunchedEffect(semi, tempo) { engine.semi = semi; engine.tempo = tempo.toDouble() }
    LaunchedEffect(Unit) { while (true) {
        pos = engine.positionMs; playing = engine.playing
        vp?.let { v -> v.playWhenReady = engine.playing; v.setPlaybackSpeed(engine.tempo.toFloat())
            if (kotlin.math.abs(v.currentPosition - pos) > 150) v.seekTo(pos) }
        delay(200) } }
    val dur = engine.durationMs.coerceAtLeast(1)
    val sc = SliderDefaults.colors(thumbColor = Cyan, activeTrackColor = Cyan)

    Column(Modifier.fillMaxSize().statusBarsPadding().verticalScroll(rememberScrollState()).padding(22.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween, Alignment.CenterVertically) {
            Text("Instrumental", fontSize = 24.sp, fontWeight = FontWeight.ExtraBold); TextButton(onBack) { Text("New file") } }
        Card {
            if (vp != null) AndroidView({ PlayerView(it).apply { player = vp; useController = false; keepScreenOn = keepOn } },
                Modifier.fillMaxWidth().aspectRatio(16 / 9f).clip(RoundedCornerShape(16.dp)))
            else Equalizer(playing, Modifier.fillMaxWidth().height(120.dp))
            Slider(pos.toFloat(), { engine.seekMs(it.toLong()); pos = it.toLong() }, valueRange = 0f..dur.toFloat(), colors = sc)
            Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween) {
                Hint("${pos / 60000}:%02d".format(pos / 1000 % 60)); Hint("${dur / 60000}:%02d".format(dur / 1000 % 60)) }
            Box(Modifier.align(Alignment.CenterHorizontally).size(76.dp).clip(CircleShape).background(Brand)
                .clickable { if (playing) engine.pause() else engine.play() }, Alignment.Center) {
                Canvas(Modifier.size(28.dp)) {
                    if (playing) { val w = size.width * 0.32f
                        drawRoundRect(Bg, Offset(size.width * 0.05f, 0f), Size(w, size.height), CornerRadius(4f))
                        drawRoundRect(Bg, Offset(size.width * 0.63f, 0f), Size(w, size.height), CornerRadius(4f))
                    } else { val path = Path().apply { moveTo(size.width * 0.12f, 0f); lineTo(size.width, size.height / 2)
                        lineTo(size.width * 0.12f, size.height); close() }; drawPath(path, Bg) } } } }
        Card {
            Label("Key")
            Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween, Alignment.CenterVertically) {
                RoundBtn("−") { if (semi > -12) semi-- }
                Text("${if (semi > 0) "+" else ""}$semi", fontSize = 44.sp, fontWeight = FontWeight.ExtraBold)
                RoundBtn("+") { if (semi < 12) semi++ } }
            Hint("Semitones. Tempo stays the same.") }
        Card {
            Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween, Alignment.CenterVertically) {
                Label("Tempo"); Text("${(tempo * 100).toInt()}%", fontSize = 24.sp, fontWeight = FontWeight.ExtraBold) }
            Slider(tempo, { tempo = (it * 20).toInt() / 20f }, valueRange = 0.5f..1.5f, colors = sc)
            Hint("Pitch stays the same.") }
        Row(Modifier.fillMaxWidth(), Arrangement.spacedBy(10.dp)) {
            OutlinedButton({ semi = 0; tempo = 1f }, Modifier.weight(1f)) { Text("Reset") }
            OutlinedButton(onSave, Modifier.weight(1f)) { Text("Save instrumental") } }
    }
}
