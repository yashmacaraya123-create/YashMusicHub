package com.instrumentalizer

import android.media.*
import java.io.File
import java.nio.*
import kotlin.math.pow

/** Real-time player: instrumental WAV -> Rubber Band (R3 "finer" engine) -> AudioTrack.
 *  Key (pitch) and tempo are fully independent and are changed live. */
class RbEngine(wav: File) {
    companion object { init { System.loadLibrary("rb_jni") } }
    private external fun nCreate(sr: Int): Long
    private external fun nSet(h: Long, timeRatio: Double, pitch: Double)
    private external fun nRequired(h: Long): Int
    private external fun nProcess(h: Long, l: FloatArray, r: FloatArray, n: Int)
    private external fun nAvailable(h: Long): Int
    private external fun nRetrieve(h: Long, l: FloatArray, r: FloatArray, n: Int): Int
    private external fun nReset(h: Long)
    private external fun nDestroy(h: Long)

    private val SR = 44100
    private val data: ShortArray
    private val total: Int
    init {
        val b = ByteBuffer.wrap(wav.readBytes()).order(ByteOrder.LITTLE_ENDIAN); b.position(44)
        data = ShortArray(b.remaining() / 2); b.asShortBuffer().get(data); total = data.size / 2
    }
    val durationMs get() = total * 1000L / SR
    @Volatile var playing = false; @Volatile var ended = false
    @Volatile var tempo = 1.0; @Volatile var semi = 0
    @Volatile private var pos = 0L
    @Volatile private var seek = -1L
    @Volatile private var running = true
    // pos counts source frames fed; subtract the ~0.2 s of engine + output buffering so it matches what you hear
    val positionMs get() = ((minOf(pos, total.toLong()) - 10000).coerceAtLeast(0)) * 1000 / SR

    private val h = nCreate(SR)
    private val track = AudioTrack.Builder()
        .setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build())
        .setAudioFormat(AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_16BIT).setSampleRate(SR).setChannelMask(AudioFormat.CHANNEL_OUT_STEREO).build())
        .setBufferSizeInBytes(32768).setTransferMode(AudioTrack.MODE_STREAM).build()
    private val thread = Thread { loop() }.apply { start() }

    fun play() { if (ended) { seekMs(0); ended = false }; playing = true }
    fun pause() { playing = false }
    fun seekMs(ms: Long) { seek = (ms * SR / 1000).coerceIn(0, total.toLong()) }
    fun release() { running = false; thread.join(); track.release(); nDestroy(h) }

    private fun loop() {
        val l = FloatArray(2048); val r = FloatArray(2048); val sb = ShortArray(4096)
        var lastRatio = -1.0; var lastPitch = -1.0
        while (running) {
            if (!playing) { track.pause(); Thread.sleep(20); continue }
            track.play()
            if (seek >= 0) { pos = seek; seek = -1; nReset(h); track.pause(); track.flush(); track.play() }
            val ratio = 1.0 / tempo; val pitch = 2.0.pow(semi / 12.0)
            if (ratio != lastRatio || pitch != lastPitch) { nSet(h, ratio, pitch); lastRatio = ratio; lastPitch = pitch }
            val need = nRequired(h)
            if (need > 0) {
                val n = minOf(need, 2048)
                for (i in 0 until n) { val k = (pos + i).toInt()
                    if (k < total) { l[i] = data[2 * k] / 32768f; r[i] = data[2 * k + 1] / 32768f } else { l[i] = 0f; r[i] = 0f } }
                nProcess(h, l, r, n); pos += n
            }
            var av = nAvailable(h)
            while (av > 0 && seek < 0 && running) {
                val g = nRetrieve(h, l, r, minOf(av, 2048))
                for (i in 0 until g) { sb[2 * i] = (l[i].coerceIn(-1f, 1f) * 32767f).toInt().toShort(); sb[2 * i + 1] = (r[i].coerceIn(-1f, 1f) * 32767f).toInt().toShort() }
                track.write(sb, 0, g * 2); av -= g
            }
            if (pos >= total + 8192) { playing = false; ended = true }
        }
    }
}
