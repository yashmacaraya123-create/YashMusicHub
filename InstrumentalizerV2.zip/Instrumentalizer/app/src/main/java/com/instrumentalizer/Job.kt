package com.instrumentalizer

import kotlinx.coroutines.flow.MutableStateFlow
import java.io.File

data class JobState(val progress: Float? = null, val wav: File? = null, val error: String? = null)

/** Shared state between the UI and the background separation service. */
object Job {
    val state = MutableStateFlow(JobState())
    @Volatile var cancel = false
}
