#include <jni.h>
#include "rubberband/rubberband/RubberBandStretcher.h"
using namespace RubberBand;
#define FN(r, n) extern "C" JNIEXPORT r JNICALL Java_com_instrumentalizer_RbEngine_##n
static RubberBandStretcher* S(jlong h) { return reinterpret_cast<RubberBandStretcher*>(h); }

FN(jlong, nCreate)(JNIEnv*, jobject, jint sr) {
    return reinterpret_cast<jlong>(new RubberBandStretcher(sr, 2,
        RubberBandStretcher::OptionProcessRealTime | RubberBandStretcher::OptionEngineFiner |
        RubberBandStretcher::OptionChannelsTogether));
}
FN(void, nSet)(JNIEnv*, jobject, jlong h, jdouble ratio, jdouble pitch) { S(h)->setTimeRatio(ratio); S(h)->setPitchScale(pitch); }
FN(jint, nRequired)(JNIEnv*, jobject, jlong h) { return (jint)S(h)->getSamplesRequired(); }
FN(jint, nAvailable)(JNIEnv*, jobject, jlong h) { return (jint)S(h)->available(); }
FN(void, nReset)(JNIEnv*, jobject, jlong h) { S(h)->reset(); }
FN(void, nDestroy)(JNIEnv*, jobject, jlong h) { delete S(h); }
FN(void, nProcess)(JNIEnv* e, jobject, jlong h, jfloatArray l, jfloatArray r, jint n) {
    jfloat* a = e->GetFloatArrayElements(l, nullptr); jfloat* b = e->GetFloatArrayElements(r, nullptr);
    const float* in[2] = {a, b}; S(h)->process(in, n, false);
    e->ReleaseFloatArrayElements(l, a, JNI_ABORT); e->ReleaseFloatArrayElements(r, b, JNI_ABORT);
}
FN(jint, nRetrieve)(JNIEnv* e, jobject, jlong h, jfloatArray l, jfloatArray r, jint n) {
    jfloat* a = e->GetFloatArrayElements(l, nullptr); jfloat* b = e->GetFloatArrayElements(r, nullptr);
    float* out[2] = {a, b}; size_t got = S(h)->retrieve(out, n);
    e->ReleaseFloatArrayElements(l, a, 0); e->ReleaseFloatArrayElements(r, b, 0);
    return (jint)got;
}
