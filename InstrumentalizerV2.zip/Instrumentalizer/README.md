# Instrumentalizer v2 (Android)
- Build with GitHub Actions (see chat) or Android Studio. arm64 phones only.
- Rubber Band (GPL v2+) is cloned into app/src/main/cpp/rubberband at build time.
- The voice model (~170 MB) is NOT inside the APK: the app downloads it once on first launch
  (or import model.onnx via "I already have the file"). After that it is fully offline.
