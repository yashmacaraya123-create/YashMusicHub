# Instrumentalizer (Android, fully offline)
Setup (once):
1. Rubber Band engine (key/tempo): `git clone --depth 1 https://github.com/breakfastquay/rubberband app/src/main/cpp/rubberband`
   (delete PUT_RUBBERBAND_HERE.txt first). Install NDK + CMake from Android Studio's SDK Manager.
   LICENSE: Rubber Band is GPL v2+. Shipping a closed-source/commercial app needs a commercial licence from Breakfast Quay.
2. Separation model: put your ONNX model at app/src/main/assets/model.onnx
   (input [1,2,343980] float32 stereo 44.1 kHz -> output [1,4,2,343980], stems: drums, bass, other, vocals; e.g. htdemucs-dml.onnx from huggingface.co/ferrite-stems/htdemucs-onnx-dml).
   Different model? Edit VOCAL / SEG in Separator.kt.
3. Open in Android Studio (Koala+), sync, run on a real device (arm64).
Features: background vocal removal with notification + Cancel, live key (±12) and tempo (50-150%) via Rubber Band R3,
video support (picture synced to the instrumental), save instrumental WAV, settings, no accounts/network.
