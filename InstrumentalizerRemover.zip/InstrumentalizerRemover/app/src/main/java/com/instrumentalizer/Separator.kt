package com.instrumentalizer

import ai.onnxruntime.*
import android.content.Context
import android.media.*
import android.net.Uri
import java.io.File
import java.nio.*
import java.util.concurrent.CancellationException
import kotlin.math.*

/** Decode (optionally only a part) -> separate with the chosen model -> instrumental WAV. */
object Separator {
    const val SR = 44100
    private const val SEG = 343980          // Demucs window (7.8 s)
    private const val VOCAL = 3             // stems: drums, bass, other, vocals
    private const val NF = 7680; private const val HOP = 1024; private const val DIMF = 3072; private const val FR = 256
    private const val CH = HOP * (FR - 1)   // MDX chunk = 261120 samples
    private const val COMP = 1.009f         // Kim Vocal 2 compensation

    fun run(ctx: Context, uri: Uri, m: Model, startSec: Double, endSec: Double, overlap: Float, threads: Int,
            cancel: () -> Boolean, onP: (Float, Int?) -> Unit): File {
        val mf = m.file(ctx)
        if (!mf.exists()) throw IllegalStateException("The ${m.title} model is not installed. Open Settings, then Models.")
        val t0 = System.nanoTime()
        val prog = { p: Float -> val el = (System.nanoTime() - t0) / 1e9
            onP(p, if (p > 0.03f) (el * (1 - p) / p).toInt() else null) }
        val pcm = decode(ctx, uri, startSec, endSec)
        if (pcm[0].size < SR / 2) throw IllegalStateException("The selected part is too short.")
        val env = OrtEnvironment.getEnvironment()
        val so = OrtSession.SessionOptions().apply {
            setIntraOpNumThreads(threads); setOptimizationLevel(OrtSession.SessionOptions.OptLevel.ALL_OPT) }
        val ses = env.createSession(mf.absolutePath, so)
        val out = try { if (m.mdx) mdx(ses, env, pcm, cancel, prog) else demucs(ses, env, pcm, m.norm, overlap, cancel, prog) }
                  finally { ses.close() }
        val f = File(ctx.cacheDir, "instrumental.wav"); writeWav(f, out); return f
    }

    @Suppress("UNCHECKED_CAST")
    private fun demucs(ses: OrtSession, env: OrtEnvironment, pcm: Array<FloatArray>, norm: Boolean, overlap: Float,
                       cancel: () -> Boolean, prog: (Float) -> Unit): Array<FloatArray> {
        val n = pcm[0].size
        var mean = 0f; var std = 1f
        if (norm) {   // Demucs-style normalisation (needed by the shrunk model)
            var s = 0.0; for (i in 0 until n) s += (pcm[0][i] + pcm[1][i]) * 0.5
            val mu = s / n; var v = 0.0
            for (i in 0 until n) { val d = (pcm[0][i] + pcm[1][i]) * 0.5 - mu; v += d * d }
            mean = mu.toFloat(); std = sqrt(v / max(1, n - 1)).toFloat()
            for (c in 0..1) for (i in 0 until n) pcm[c][i] = (pcm[c][i] - mean) / (1e-5f + std)
        }
        val out = Array(2) { FloatArray(n) }; val wsum = FloatArray(n)
        val hop = max(1, (SEG * (1 - overlap)).toInt())
        val win = FloatArray(SEG) { minOf(it + 1, SEG - it).toFloat() }
        val name = ses.inputNames.first()
        var s = 0
        while (true) {
            if (cancel()) throw CancellationException()
            val len = minOf(SEG, n - s)
            val buf = FloatArray(2 * SEG)
            for (c in 0..1) System.arraycopy(pcm[c], s, buf, c * SEG, len)
            val t = OnnxTensor.createTensor(env, FloatBuffer.wrap(buf), longArrayOf(1, 2, SEG.toLong()))
            ses.run(mapOf(name to t)).use { r ->
                val y = (r[0].value as Array<Array<Array<FloatArray>>>)[0]
                for (st in y.indices) if (st != VOCAL) for (c in 0..1) for (i in 0 until len) out[c][s + i] += y[st][c][i] * win[i]
                for (i in 0 until len) wsum[s + i] += win[i]
            }
            t.close(); prog(min(1f, (s + len).toFloat() / n))
            if (s + len >= n) break
            s += hop
        }
        for (c in 0..1) for (i in 0 until n) { var v = if (wsum[i] > 0) out[c][i] / wsum[i] else 0f
            if (norm) v = v * std + 3f * mean; out[c][i] = v }
        return out
    }

    /** MDX-Net (Kim Vocal 2): STFT -> model predicts vocals -> ISTFT; instrumental = mix - vocals. */
    @Suppress("UNCHECKED_CAST")
    private fun mdx(ses: OrtSession, env: OrtEnvironment, pcm: Array<FloatArray>, cancel: () -> Boolean,
                    prog: (Float) -> Unit): Array<FloatArray> {
        val n = pcm[0].size; val trim = NF / 2; val gen = CH - 2 * trim
        val total = n + (gen - n % gen)
        val xp = Array(2) { c -> FloatArray(trim + total + trim).also { System.arraycopy(pcm[c], 0, it, trim, n) } }
        val voc = Array(2) { FloatArray(total) }
        val win = DoubleArray(NF) { 0.5 - 0.5 * cos(2 * PI * it / NF) }
        val envSum = DoubleArray(NF + HOP * (FR - 1))
        for (t in 0 until FR) for (k in 0 until NF) envSum[t * HOP + k] += win[k] * win[k]
        val bs = Bluestein(NF)
        val re = DoubleArray(NF); val im = DoubleArray(NF)
        val spec = FloatArray(4 * DIMF * FR)
        val yl = DoubleArray(envSum.size); val yr = DoubleArray(envSum.size)
        val name = ses.inputNames.first()
        var i = 0
        while (i < total) {
            if (cancel()) throw CancellationException()
            for (t in 0 until FR) {   // two channels packed into one complex FFT
                for (k in 0 until NF) {
                    var q = t * HOP + k - trim
                    if (q < 0) q = -q else if (q >= CH) q = 2 * (CH - 1) - q
                    re[k] = xp[0][i + q] * win[k]; im[k] = xp[1][i + q] * win[k]
                }
                bs.forward(re, im)
                for (k in 0 until DIMF) {
                    val nk = (NF - k) % NF
                    val a = re[k]; val b = im[k]; val c = re[nk]; val d = im[nk]
                    val z = k < 3   // lowest 3 bins are zeroed, as in UVR
                    spec[(0 * DIMF + k) * FR + t] = if (z) 0f else ((a + c) / 2).toFloat()
                    spec[(1 * DIMF + k) * FR + t] = if (z) 0f else ((b - d) / 2).toFloat()
                    spec[(2 * DIMF + k) * FR + t] = if (z) 0f else ((b + d) / 2).toFloat()
                    spec[(3 * DIMF + k) * FR + t] = if (z) 0f else (-(a - c) / 2).toFloat()
                }
            }
            val tensor = OnnxTensor.createTensor(env, FloatBuffer.wrap(spec), longArrayOf(1, 4, DIMF.toLong(), FR.toLong()))
            java.util.Arrays.fill(yl, 0.0); java.util.Arrays.fill(yr, 0.0)
            ses.run(mapOf(name to tensor)).use { r ->
                val y = (r[0].value as Array<Array<Array<FloatArray>>>)[0]
                for (t in 0 until FR) {
                    java.util.Arrays.fill(re, 0.0); java.util.Arrays.fill(im, 0.0)
                    for (k in 0 until DIMF) {
                        val lr = y[0][k][t].toDouble(); val li = y[1][k][t].toDouble()
                        val rr = y[2][k][t].toDouble(); val ri = y[3][k][t].toDouble()
                        re[k] = lr - ri; im[k] = li + rr
                        if (k > 0) { re[NF - k] = lr + ri; im[NF - k] = -li + rr }
                    }
                    bs.inverse(re, im)
                    val o = t * HOP
                    for (k in 0 until NF) { yl[o + k] += re[k] / NF * win[k]; yr[o + k] += im[k] / NF * win[k] }
                }
            }
            tensor.close()
            for (j in 0 until gen) { val idx = trim + j
                voc[0][i + j] = (yl[idx] / envSum[idx] * COMP).toFloat(); voc[1][i + j] = (yr[idx] / envSum[idx] * COMP).toFloat() }
            i += gen; prog(min(1f, i.toFloat() / total))
        }
        return Array(2) { c -> FloatArray(n) { j -> pcm[c][j] - voc[c][j] } }
    }

    private fun decode(ctx: Context, uri: Uri, startSec: Double, endSec: Double): Array<FloatArray> {
        val ex = MediaExtractor().apply { setDataSource(ctx, uri, null) }
        val ti = (0 until ex.trackCount).first { ex.getTrackFormat(it).getString(MediaFormat.KEY_MIME)!!.startsWith("audio") }
        ex.selectTrack(ti)
        val fmt = ex.getTrackFormat(ti)
        val codec = MediaCodec.createDecoderByType(fmt.getString(MediaFormat.KEY_MIME)!!)
        codec.configure(fmt, null, null, 0); codec.start()
        var ch = fmt.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
        var sr = fmt.getInteger(MediaFormat.KEY_SAMPLE_RATE)
        var data = ShortArray(1 shl 22); var len = 0
        val info = MediaCodec.BufferInfo(); var inDone = false; var outDone = false
        while (!outDone) {
            if (!inDone) {
                val i = codec.dequeueInputBuffer(10000)
                if (i >= 0) {
                    val sz = ex.readSampleData(codec.getInputBuffer(i)!!, 0)
                    if (sz < 0) { codec.queueInputBuffer(i, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM); inDone = true }
                    else { codec.queueInputBuffer(i, 0, sz, ex.sampleTime, 0); ex.advance() }
                }
            }
            val o = codec.dequeueOutputBuffer(info, 10000)
            if (o >= 0) {
                val sb = codec.getOutputBuffer(o)!!.order(ByteOrder.nativeOrder()).asShortBuffer()
                val k = info.size / 2
                if (len + k > data.size) data = data.copyOf(maxOf(data.size * 2, len + k))
                sb.get(data, len, k); len += k
                codec.releaseOutputBuffer(o, false)
                if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0 || len / ch >= min(endSec, 1e6) * sr) outDone = true
            } else if (o == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                ch = codec.outputFormat.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
                sr = codec.outputFormat.getInteger(MediaFormat.KEY_SAMPLE_RATE)
            }
        }
        codec.stop(); codec.release(); ex.release()
        val frames = len / ch
        val s0 = (startSec * sr).toInt().coerceIn(0, frames); val s1 = min(frames.toDouble(), min(endSec, 1e6) * sr).toInt()
        val cnt = max(0, s1 - s0)
        val raw = Array(2) { c -> FloatArray(cnt) { data[(s0 + it) * ch + if (ch > 1) c else 0] / 32768f } }
        if (sr == SR) return raw
        val m = (cnt.toLong() * SR / sr).toInt()
        return Array(2) { c -> FloatArray(m) { i ->
            val p = i.toDouble() * sr / SR; val a = p.toInt(); val fr = (p - a).toFloat()
            raw[c][a] * (1 - fr) + raw[c][min(a + 1, cnt - 1)] * fr } }
    }

    private fun writeWav(f: File, d: Array<FloatArray>) {
        val n = d[0].size
        val b = ByteBuffer.allocate(44 + n * 4).order(ByteOrder.LITTLE_ENDIAN)
        b.put("RIFF".toByteArray()).putInt(36 + n * 4).put("WAVEfmt ".toByteArray()).putInt(16)
            .putShort(1).putShort(2).putInt(SR).putInt(SR * 4).putShort(4).putShort(16)
            .put("data".toByteArray()).putInt(n * 4)
        for (i in 0 until n) for (c in 0..1) b.putShort((d[c][i].coerceIn(-1f, 1f) * 32767f).toInt().toShort())
        f.writeBytes(b.array())
    }
}
