package com.instrumentalizer

import android.content.Intent
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.*
import androidx.compose.ui.graphics.*
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import kotlinx.coroutines.*
import java.io.File

private val Bg = Color(0xFF0E0B1F)
private val PanelC = Color(0xFF181440)
private val Cyan = Color(0xFF5EEAD4)
private val Violet = Color(0xFFC084FC)
private val Pink = Color(0xFFF472B6)
private val Brand = Brush.linearGradient(listOf(Cyan, Violet, Pink))
private val DarkC = darkColorScheme(primary = Cyan, onPrimary = Bg, secondary = Violet, tertiary = Pink,
    background = Bg, surface = Bg, surfaceVariant = PanelC, onBackground = Color(0xFFEDEBFF),
    onSurface = Color(0xFFEDEBFF), onSurfaceVariant = Color(0xFFA9A5D0), outline = Color(0xFF3A3470),
    secondaryContainer = Color(0xFF3A2C75), onSecondaryContainer = Color(0xFFEDEBFF))
private val LightC = lightColorScheme(primary = Color(0xFF0F766E), secondary = Color(0xFF7C3AED), tertiary = Color(0xFFDB2777),
    background = Color(0xFFF6F4FF), surface = Color(0xFFF6F4FF), surfaceVariant = Color(0xFFFFFFFF),
    onSurfaceVariant = Color(0xFF5B5780), outline = Color(0xFFD5D0F0))

fun fmt(s: Double): String { val t = s.toInt(); return "${t / 60}:%02d".format(t % 60) }
fun span(sec: Int) = if (sec < 90) "$sec sec" else "${(sec + 30) / 60} min"

class MainActivity : ComponentActivity() {
    override fun onCreate(s: Bundle?) { super.onCreate(s); setContent { App() } }
}

@Composable fun BrandButton(text: String, enabled: Boolean = true, onClick: () -> Unit) {
    Box(Modifier.clip(RoundedCornerShape(50)).background(if (enabled) Brand else Brush.linearGradient(listOf(Color(0xFF555070), Color(0xFF555070))))
        .clickable(enabled = enabled, onClick = onClick).padding(horizontal = 30.dp, vertical = 16.dp), Alignment.Center) {
        Text(text, color = Bg, fontWeight = FontWeight.Bold, fontSize = 16.sp) } }

@Composable fun Card(content: @Composable ColumnScope.() -> Unit) {
    val sh = RoundedCornerShape(26.dp)
    Column(Modifier.fillMaxWidth().clip(sh).background(MaterialTheme.colorScheme.surfaceVariant)
        .border(1.dp, MaterialTheme.colorScheme.outline, sh).padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp), content = content) }

@Composable fun Label(t: String) = Text(t.uppercase(), color = MaterialTheme.colorScheme.primary,
    fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp)
@Composable fun Hint(t: String) = Text(t, color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 13.sp)

@Composable fun Chips(opts: List<Pair<String, String>>, sel: String, onSel: (String) -> Unit) {
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        opts.forEach { (k, l) -> FilterChip(sel == k, { onSel(k) }, { Text(l) }) } } }

@Composable fun Logo() {
    Box(Modifier.size(104.dp).clip(RoundedCornerShape(30.dp)).background(Color(0xFF14102B))
        .border(1.5.dp, Brand, RoundedCornerShape(30.dp)), Alignment.Center) {
        Image(painterResource(R.drawable.ic_launcher_foreground), null, Modifier.size(104.dp).scale(1.45f)) } }

@Composable fun Equalizer(active: Boolean, modifier: Modifier = Modifier) {
    val t by rememberInfiniteTransition(label = "eq").animateFloat(0f, 1f,
        infiniteRepeatable(tween(1800, easing = LinearEasing)), label = "t")
    Canvas(modifier) {
        val n = 28; val gap = size.width / n; val w = gap * 0.55f
        for (i in 0 until n) {
            val a = if (active) 0.22f + 0.78f * kotlin.math.abs(kotlin.math.sin(t * 2f * Math.PI.toFloat() * (1 + i % 3) + i * 0.55f)) else 0.16f
            val h = size.height * a
            drawRoundRect(Brand, Offset(i * gap + (gap - w) / 2, (size.height - h) / 2), Size(w, h), CornerRadius(w / 2)) } } }

@Composable fun Page(content: @Composable ColumnScope.() -> Unit) {
    Column(Modifier.fillMaxSize().statusBarsPadding().verticalScroll(rememberScrollState()).padding(22.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp), content = content) }

@Composable fun App() {
    val ctx = LocalContext.current
    val prefs = remember { ctx.getSharedPreferences("s", 0) }
    var theme by remember { mutableStateOf(prefs.getString("theme", "system")!!) }
    var modelKey by remember { mutableStateOf(prefs.getString("model", "studio")!!) }
    var overlap by remember { mutableStateOf(prefs.getString("overlap", "normal")!!) }
    var cpu by remember { mutableStateOf(prefs.getString("cpu", "smooth")!!) }
    var page by remember { mutableStateOf("home") }
    var src by remember { mutableStateOf<Uri?>(null) }
    var name by remember { mutableStateOf("") }
    var dur by remember { mutableDoubleStateOf(1.0) }
    var from by remember { mutableDoubleStateOf(0.0) }
    var to by remember { mutableDoubleStateOf(1.0) }
    var wav by remember { mutableStateOf<File?>(null) }
    var msg by remember { mutableStateOf<String?>(null) }
    var dlKey by remember { mutableStateOf<String?>(null) }
    var dl by remember { mutableFloatStateOf(0f) }
    var tick by remember { mutableIntStateOf(0) }
    var importFor by remember { mutableStateOf<Model?>(null) }
    val js by Job.state.collectAsState()
    val scope = rememberCoroutineScope()
    val model = Model.from(modelKey)
    fun has(m: Model) = tick >= 0 && m.file(ctx).exists()
    fun put(k: String, v: String) = prefs.edit().putString(k, v).apply()

    LaunchedEffect(js.wav) { js.wav?.let { wav = it; if (page == "home") page = "result" } }

    fun download(m: Model) {
        dlKey = m.key; dl = 0f; msg = null
        scope.launch {
            try { ModelStore.download(ctx, m) { dl = it }; tick++ }
            catch (e: Throwable) { msg = "Download failed: ${e.message}" }
            dlKey = null } }

    val pick = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            src = uri; msg = null; page = "prepare"; name = "Selected file"
            ctx.contentResolver.query(uri, null, null, null, null)?.use { c ->
                val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME); if (c.moveToFirst() && i >= 0) name = c.getString(i) }
            scope.launch(Dispatchers.IO) {
                var d = 600.0
                val r = MediaMetadataRetriever()
                try { r.setDataSource(ctx, uri)
                    d = (r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toDoubleOrNull() ?: 600000.0) / 1000.0
                } catch (_: Throwable) {} finally { r.release() }
                dur = maxOf(d, 2.0); from = 0.0; to = dur } } }
    val importer = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u ->
        val m = importFor
        if (u != null && m != null) scope.launch(Dispatchers.IO) {
            try { ModelStore.import(ctx, m, u); tick++ } catch (e: Throwable) { msg = "Import failed: ${e.message}" } } }
    val askNotif = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {}
    LaunchedEffect(Unit) { if (android.os.Build.VERSION.SDK_INT >= 33) askNotif.launch(android.Manifest.permission.POST_NOTIFICATIONS) }
    val save = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("audio/wav")) { u ->
        if (u != null) ctx.contentResolver.openOutputStream(u)?.use { o -> wav?.inputStream()?.use { it.copyTo(o) } } }

    fun start() {
        val cores = Runtime.getRuntime().availableProcessors()
        ctx.startForegroundService(Intent(ctx, SeparationService::class.java).setData(src)
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            .putExtra("model", model.key).putExtra("start", from).putExtra("end", to)
            .putExtra("overlap", when (overlap) { "quick" -> 0.1f; "max" -> 0.5f; else -> 0.25f })
            .putExtra("threads", if (cpu == "fast") (cores - 1).coerceAtLeast(2) else (cores / 2 - 1).coerceAtLeast(2)))
        page = "home" }

    val dark = when (theme) { "dark" -> true; "light" -> false; else -> isSystemInDarkTheme() }
    MaterialTheme(colorScheme = if (dark) DarkC else LightC) {
        Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
            when (page) {
                "prepare" -> Page {
                    Text("Prepare", fontSize = 28.sp, fontWeight = FontWeight.ExtraBold)
                    Card { Label("File"); Text(name, fontWeight = FontWeight.SemiBold); Hint("Length ${fmt(dur)}") }
                    Card {
                        Label("Part to process")
                        Text("${fmt(from)} to ${fmt(to)}  (${span((to - from).toInt())})", fontWeight = FontWeight.SemiBold)
                        Hint("Start"); Slider(from.toFloat(), { from = it.toDouble().coerceAtMost(to - 1.0) }, valueRange = 0f..dur.toFloat())
                        Hint("End"); Slider(to.toFloat(), { to = it.toDouble().coerceAtLeast(from + 1.0) }, valueRange = 0f..dur.toFloat())
                        TextButton({ from = 0.0; to = dur }) { Text("Whole song") } }
                    Card {
                        Label("Model")
                        Chips(Model.entries.map { it.key to it.title }, modelKey) { modelKey = it; put("model", it) }
                        Hint(model.blurb)
                        if (!has(model)) { Text("This model is not installed yet.", color = MaterialTheme.colorScheme.error)
                            OutlinedButton({ page = "models" }) { Text("Get the model") } } }
                    Card {
                        Label("Estimate")
                        val rate = prefs.getFloat("rate_${model.key}", -1f)
                        Text(if (rate > 0) "About ${span((rate * (to - from)).toInt())}" else "Shown after the first moments of processing",
                            fontSize = 20.sp, fontWeight = FontWeight.ExtraBold)
                        Hint(if (rate > 0) "Based on your last ${model.title} run on this phone." else "I learn your phone's speed from the first run.")
                        Hint("Using: ${model.title} · overlap ${overlap} · phone load ${cpu}") }
                    BrandButton("Remove vocals", has(model)) { start() }
                    TextButton({ page = "home" }) { Text("Cancel") }
                }
                "result" -> ResultScreen(wav!!, { page = "home" }, { save.launch("instrumental.wav") })
                "models" -> Page {
                    Text("Models", fontSize = 28.sp, fontWeight = FontWeight.ExtraBold)
                    Hint("Download once; after that everything works offline. Tip: keep a copy of each file in your Downloads folder, then use Import after a reinstall.")
                    Model.entries.forEach { m ->
                        Card {
                            Label(m.title); Text(m.blurb)
                            Hint("${m.size} · " + if (has(m)) "Installed" else "Not installed")
                            if (dlKey == m.key) { LinearProgressIndicator({ dl }, Modifier.fillMaxWidth()); Hint("Downloading ${(dl * 100).toInt()}%. Keep the app open.") }
                            else {
                                if (!has(m)) FilledTonalButton({ download(m) }) { Text("Download") }
                                OutlinedButton({ importFor = m; importer.launch(arrayOf("*/*")) }) { Text("Import file") }
                                if (has(m)) OutlinedButton({ m.file(ctx).delete(); tick++ }) { Text("Delete") } } } }
                    msg?.let { Text(it, color = MaterialTheme.colorScheme.error) }
                    BrandButton("Back") { page = "settings" }
                }
                "settings" -> Page {
                    Text("Settings", fontSize = 28.sp, fontWeight = FontWeight.ExtraBold)
                    Hint("Changes save instantly and apply to the next file you process.")
                    Card { Label("Appearance"); Chips(listOf("system" to "System", "light" to "Light", "dark" to "Dark"), theme) { theme = it; put("theme", it) } }
                    Card {
                        Label("Default model")
                        Chips(Model.entries.map { it.key to it.title }, modelKey) { modelKey = it; put("model", it) }
                        Label("Overlap")
                        Chips(listOf("quick" to "Quick", "normal" to "Normal", "max" to "Max"), overlap) { overlap = it; put("overlap", it) }
                        Hint("Higher overlap is cleaner but slower. Applies to Studio and Balanced.")
                        Label("Phone load")
                        Chips(listOf("smooth" to "Smooth", "fast" to "Fast"), cpu) { cpu = it; put("cpu", it) }
                        Hint("Smooth keeps your phone responsive. Fast finishes sooner but may lag.") }
                    Card { Label("Models"); Hint("Download, import or delete the voice models.")
                        OutlinedButton({ page = "models" }) { Text("Manage models") } }
                    Card { Label("Background")
                        Hint("If processing stops when you leave the app, allow background running and set this app's battery to Unrestricted.")
                        OutlinedButton({ ctx.startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)) }) { Text("Allow background running") } }
                    Card { Label("Storage")
                        OutlinedButton({ ctx.cacheDir.listFiles()?.forEach { it.delete() }; wav = null }) { Text("Clear temporary files") } }
                    BrandButton("Back") { page = "home" }
                }
                else -> Column(Modifier.fillMaxSize().statusBarsPadding().verticalScroll(rememberScrollState()).padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(14.dp)) {
                    Row(Modifier.fillMaxWidth(), Arrangement.End) { TextButton({ page = "settings" }) { Text("Settings") } }
                    Spacer(Modifier.height(16.dp))
                    Logo()
                    Text("Instrumentalizer", style = TextStyle(brush = Brand, fontSize = 32.sp, fontWeight = FontWeight.ExtraBold))
                    Hint("Vocals out. Music in.")
                    Spacer(Modifier.height(10.dp))
                    val p = js.progress
                    Card {
                        if (p != null) {
                            Equalizer(true, Modifier.fillMaxWidth().height(70.dp))
                            Text("Removing vocals… ${(p * 100).toInt()}%", fontWeight = FontWeight.SemiBold)
                            LinearProgressIndicator({ p }, Modifier.fillMaxWidth())
                            Hint(js.eta?.let { "About ${span(it)} left. Keeps running in the background." } ?: "Working out the time left…")
                            OutlinedButton({ Job.cancel = true }) { Text("Cancel") }
                        } else {
                            Equalizer(false, Modifier.fillMaxWidth().height(70.dp))
                            BrandButton("Choose a song or video") { pick.launch(arrayOf("audio/*", "video/*")) }
                            if (wav != null) TextButton({ page = "result" }) { Text("Back to last result") }
                            if (Model.entries.none { has(it) }) { Hint("First, download a voice model.")
                                OutlinedButton({ page = "models" }) { Text("Get a model") } }
                        }
                    }
                    (msg ?: js.error)?.let { Text(it, color = MaterialTheme.colorScheme.error) }
                }
            }
        }
    }
}

@Composable fun ResultScreen(wav: File, onBack: () -> Unit, onSave: () -> Unit) {
    val ctx = LocalContext.current
    var playing by remember { mutableStateOf(false) }
    var pos by remember { mutableLongStateOf(0) }
    var dur by remember { mutableLongStateOf(1) }
    val player = remember { ExoPlayer.Builder(ctx).build().apply { setMediaItem(MediaItem.fromUri(Uri.fromFile(wav))); prepare() } }
    DisposableEffect(Unit) { onDispose { player.release() } }
    LaunchedEffect(Unit) { while (true) { pos = player.currentPosition; dur = player.duration.coerceAtLeast(1); playing = player.isPlaying; delay(250) } }
    val sc = SliderDefaults.colors(thumbColor = Cyan, activeTrackColor = Cyan)
    Page {
        Text("Your instrumental", fontSize = 26.sp, fontWeight = FontWeight.ExtraBold)
        Card {
            Equalizer(playing, Modifier.fillMaxWidth().height(120.dp))
            Slider(pos.toFloat(), { player.seekTo(it.toLong()); pos = it.toLong() }, valueRange = 0f..dur.toFloat(), colors = sc)
            Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween) { Hint(fmt(pos / 1000.0)); Hint(fmt(dur / 1000.0)) }
            Box(Modifier.align(Alignment.CenterHorizontally).size(76.dp).clip(CircleShape).background(Brand)
                .clickable { if (player.isPlaying) player.pause() else player.play() }, Alignment.Center) {
                Canvas(Modifier.size(28.dp)) {
                    if (playing) { val w = size.width * 0.32f
                        drawRoundRect(Bg, Offset(size.width * 0.05f, 0f), Size(w, size.height), CornerRadius(4f))
                        drawRoundRect(Bg, Offset(size.width * 0.63f, 0f), Size(w, size.height), CornerRadius(4f))
                    } else { val path = Path().apply { moveTo(size.width * 0.12f, 0f); lineTo(size.width, size.height / 2)
                        lineTo(size.width * 0.12f, size.height); close() }; drawPath(path, Bg) } } } }
        BrandButton("Save instrumental (WAV)") { onSave() }
        OutlinedButton(onBack, Modifier.fillMaxWidth()) { Text("Process another file") }
    }
}
