package com.instrumentalizer

import android.content.Context
import android.net.Uri
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

enum class Model(val key: String, val title: String, val blurb: String, val size: String, val url: String,
                 val mdx: Boolean, val norm: Boolean) {
    STUDIO("studio", "Studio", "Best quality. Slowest.", "about 170 MB",
        "https://huggingface.co/ferrite-stems/htdemucs-onnx-dml/resolve/main/htdemucs-dml.onnx", false, false),
    BALANCED("balanced", "Balanced", "A shrunk version of Studio. Somewhat faster, tiny quality loss.", "about 100 MB",
        "https://huggingface.co/redalpha7/omnimix-stems-light/resolve/main/htdemucs-compact-int8.onnx", false, true),
    FAST("fast", "Fast", "Vocal-focused model. Fastest, but may leave faint vocal traces.", "about 67 MB",
        "https://huggingface.co/uddompang/kamvox-voice-separator/resolve/main/kim-vocal-2.onnx", true, false);

    fun file(c: Context) = File(c.filesDir, "$key.onnx")
    companion object { fun from(k: String) = entries.firstOrNull { it.key == k } ?: STUDIO }
}

object ModelStore {
    suspend fun download(c: Context, m: Model, onP: (Float) -> Unit) = withContext(Dispatchers.IO) {
        val tmp = File(c.filesDir, "${m.key}.part")
        val con = URL(m.url).openConnection() as HttpURLConnection
        con.connectTimeout = 15000; con.readTimeout = 30000; con.connect()
        val total = con.contentLengthLong
        con.inputStream.use { i -> tmp.outputStream().use { o ->
            val b = ByteArray(65536); var n = 0L
            while (true) { val r = i.read(b); if (r < 0) break; o.write(b, 0, r); n += r
                if (total > 0) onP(n.toFloat() / total) } } }
        if (tmp.length() < 10_000_000) { tmp.delete(); throw IllegalStateException("incomplete file") }
        m.file(c).delete(); tmp.renameTo(m.file(c))
    }

    fun import(c: Context, m: Model, uri: Uri) {
        val tmp = File(c.filesDir, "${m.key}.part")
        c.contentResolver.openInputStream(uri)!!.use { i -> tmp.outputStream().use { i.copyTo(it) } }
        m.file(c).delete(); tmp.renameTo(m.file(c))
    }
}
