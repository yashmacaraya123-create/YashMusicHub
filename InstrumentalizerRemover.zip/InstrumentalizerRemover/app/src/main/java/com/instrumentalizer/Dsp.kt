package com.instrumentalizer

import kotlin.math.*

/** Radix-2 FFT (unscaled; inverse = conjugate twiddles). */
class Fft(private val n: Int) {
    private val cosT = DoubleArray(n / 2) { cos(2 * PI * it / n) }
    private val sinT = DoubleArray(n / 2) { sin(2 * PI * it / n) }
    private val rev = IntArray(n).also { r -> val bits = Integer.numberOfTrailingZeros(n)
        for (i in 1 until n) r[i] = (r[i shr 1] shr 1) or ((i and 1) shl (bits - 1)) }

    fun transform(re: DoubleArray, im: DoubleArray, inverse: Boolean) {
        for (i in 0 until n) { val j = rev[i]
            if (j > i) { val a = re[i]; re[i] = re[j]; re[j] = a; val b = im[i]; im[i] = im[j]; im[j] = b } }
        var size = 2
        while (size <= n) {
            val half = size / 2; val step = n / size
            var i = 0
            while (i < n) {
                var k = 0
                for (j in i until i + half) {
                    val wr = cosT[k]; val wi = if (inverse) sinT[k] else -sinT[k]
                    val tr = re[j + half] * wr - im[j + half] * wi
                    val ti = re[j + half] * wi + im[j + half] * wr
                    re[j + half] = re[j] - tr; im[j + half] = im[j] - ti
                    re[j] += tr; im[j] += ti; k += step
                }
                i += size
            }
            size = size shl 1
        }
    }
}

/** DFT of any length n (used for n_fft = 7680) via Bluestein's algorithm. */
class Bluestein(private val n: Int) {
    private val m = run { var p = 1; while (p < 2 * n - 1) p = p shl 1; p }
    private val fft = Fft(m)
    private val wr = DoubleArray(n); private val wi = DoubleArray(n)
    private val bRe = DoubleArray(m); private val bIm = DoubleArray(m)
    private val aRe = DoubleArray(m); private val aIm = DoubleArray(m)
    init {
        for (k in 0 until n) { val a = PI * ((k.toLong() * k) % (2L * n)) / n; wr[k] = cos(a); wi[k] = -sin(a) }
        bRe[0] = wr[0]; bIm[0] = -wi[0]
        for (k in 1 until n) { bRe[k] = wr[k]; bIm[k] = -wi[k]; bRe[m - k] = wr[k]; bIm[m - k] = -wi[k] }
        fft.transform(bRe, bIm, false)
    }
    fun forward(re: DoubleArray, im: DoubleArray) {
        for (k in 0 until n) { aRe[k] = re[k] * wr[k] - im[k] * wi[k]; aIm[k] = re[k] * wi[k] + im[k] * wr[k] }
        java.util.Arrays.fill(aRe, n, m, 0.0); java.util.Arrays.fill(aIm, n, m, 0.0)
        fft.transform(aRe, aIm, false)
        for (k in 0 until m) { val r = aRe[k] * bRe[k] - aIm[k] * bIm[k]; val i = aRe[k] * bIm[k] + aIm[k] * bRe[k]; aRe[k] = r; aIm[k] = i }
        fft.transform(aRe, aIm, true)
        for (k in 0 until n) { val r = aRe[k] / m; val i = aIm[k] / m; re[k] = r * wr[k] - i * wi[k]; im[k] = r * wi[k] + i * wr[k] }
    }
    /** unscaled inverse */
    fun inverse(re: DoubleArray, im: DoubleArray) {
        for (k in 0 until n) im[k] = -im[k]
        forward(re, im)
        for (k in 0 until n) im[k] = -im[k]
    }
}
