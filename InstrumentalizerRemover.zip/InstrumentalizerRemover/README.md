# Instrumentalizer (vocal removal app)
Models (downloaded in-app, or imported from a file): Studio = htdemucs, Balanced = htdemucs int8, Fast = MDX-Net Kim Vocal 2.
No Rubber Band / native code in this app. Build: see apk.yml in chat. arm64 phones.
Signed with the fixed app/debug.keystore so updates install over older builds and keep the models.
